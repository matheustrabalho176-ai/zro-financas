# Página inicial do Zro Finanças — guardada para uso futuro

A página de apresentação anterior foi preservada em `landing-page-prototype.tsx`.

Ela contém o layout escuro em azul, marca Zro Finanças, apresentação do produto, demonstração visual ilustrativa, recursos, privacidade e botões de acesso. Os botões de entrada e de começar apontam para `/auth`.

A página não faz parte das rotas ativas do aplicativo neste momento. Para criar uma página pública separada futuramente, reutilize este protótipo e registre-o em uma rota própria (por exemplo, `/inicio`).

Observação: os valores exibidos na demonstração são apenas ilustrativos e não devem ser tratados como dados reais de usuários.
