import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, BarChart3, Check, ChevronRight, Cloud, CreditCard, FileText, ShieldCheck, Target, WalletCards } from "lucide-react";
import { Brand } from "@/components/Brand";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Zro Finanças — Seu dinheiro no controle" },
    { name: "description", content: "Organize suas finanças, acompanhe seus gastos, defina metas e construa um futuro mais tranquilo." },
    { property: "og:title", content: "Zro Finanças — Seu dinheiro no controle" },
    { property: "og:description", content: "Controle receitas, despesas, cartões e metas em um só lugar." },
  ] }),
  component: Index,
});

const FEATURES = [
  { icon: BarChart3, t: "Visão completa", d: "Entenda seu saldo e acompanhe a evolução das suas finanças." },
  { icon: WalletCards, t: "Lançamentos", d: "Organize receitas e despesas sem complicação." },
  { icon: CreditCard, t: "Cartões de crédito", d: "Acompanhe faturas, limites e vencimentos." },
  { icon: Target, t: "Metas e planos", d: "Defina objetivos e acompanhe seu progresso." },
];

function Index() {
  return <div className="relative min-h-screen overflow-hidden bg-[#030d1d] text-white">
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_70%_30%,rgba(0,106,255,0.17),transparent_48%),radial-gradient(ellipse_at_0%_100%,rgba(0,75,210,0.18),transparent_45%)]" />
    <header className="relative z-10 mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8 lg:px-12">
      <Link to="/" aria-label="Zro Finanças - início"><Brand compact /></Link>
      <nav className="hidden items-center gap-9 text-sm text-slate-300 md:flex"><a href="#inicio" className="text-sky-400">Início</a><a href="#recursos" className="transition hover:text-white">Recursos</a><a href="#sobre" className="transition hover:text-white">Sobre</a></nav>
      <Button asChild className="rounded-xl bg-blue-600 px-5 text-white shadow-lg shadow-blue-900/30 hover:bg-blue-500"><Link to="/auth">Entrar <ChevronRight className="ml-1 size-4" /></Link></Button>
    </header>
    <main className="relative z-10 mx-auto max-w-7xl px-5 sm:px-8 lg:px-12">
      <section id="inicio" className="grid min-h-[610px] items-center gap-12 py-12 lg:grid-cols-[1.05fr_.95fr] lg:py-16">
        <div className="max-w-2xl">
          <div className="mb-7 inline-flex items-center gap-2 rounded-full border border-blue-400/20 bg-blue-400/10 px-3 py-1.5 text-xs font-medium text-sky-200"><span className="size-1.5 rounded-full bg-cyan-400"/> FINANÇAS PESSOAIS, DO SEU JEITO</div>
          <div className="mb-5 flex items-center gap-4"><Brand className="text-5xl sm:text-6xl" /></div>
          <h1 className="max-w-2xl text-4xl font-bold leading-[1.12] tracking-tight sm:text-5xl lg:text-6xl">Seu dinheiro no controle, <span className="bg-gradient-to-r from-sky-300 via-blue-400 to-blue-600 bg-clip-text text-transparent">seus planos em dia.</span></h1>
          <p className="mt-6 max-w-xl text-base leading-7 text-slate-300 sm:text-lg">Organize suas finanças, acompanhe seus gastos, defina metas e construa um futuro mais tranquilo — tudo em um só lugar.</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row"><Button asChild size="lg" className="h-12 rounded-full bg-blue-600 px-7 text-base text-white shadow-lg shadow-blue-900/40 hover:bg-blue-500"><Link to="/auth">Começar agora <ArrowRight className="ml-2 size-5" /></Link></Button><Button asChild size="lg" variant="outline" className="h-12 rounded-full border-slate-600 bg-slate-950/40 px-7 text-base text-white hover:bg-slate-800"><a href="#recursos">Conhecer recursos</a></Button></div>
          <div className="mt-8 flex flex-wrap gap-x-5 gap-y-2 text-sm text-slate-400"><span className="flex items-center gap-2"><Check className="size-4 text-cyan-400"/> Simples de usar</span><span className="flex items-center gap-2"><Check className="size-4 text-cyan-400"/> Seus dados por conta própria</span></div>
        </div>
        <div className="relative mx-auto w-full max-w-xl lg:pl-4">
          <div className="absolute inset-10 rounded-full bg-blue-600/20 blur-3xl" />
          <div className="relative rounded-[2rem] border border-blue-300/20 bg-gradient-to-br from-slate-800/90 via-[#07172b] to-[#020917] p-4 shadow-2xl shadow-blue-950/50 sm:p-6">
            <div className="flex items-center justify-between border-b border-white/10 pb-4"><Brand compact/><span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-xs text-emerald-300">Visão geral</span></div>
            <div className="mt-5 grid grid-cols-2 gap-3"><div className="rounded-2xl border border-white/10 bg-slate-950/60 p-4"><p className="text-xs text-slate-400">Saldo total</p><p className="mt-2 text-2xl font-bold tracking-tight">R$ 4.328,67</p><p className="mt-1 text-xs text-emerald-300">Visão das suas finanças</p></div><div className="rounded-2xl border border-white/10 bg-slate-950/60 p-4"><p className="text-xs text-slate-400">Neste mês</p><p className="mt-2 text-2xl font-bold tracking-tight">Organizado</p><p className="mt-1 text-xs text-sky-300">Receitas e despesas</p></div></div>
            <div className="mt-3 rounded-2xl border border-white/10 bg-slate-950/60 p-4"><div className="flex items-center justify-between"><div><p className="text-sm font-semibold">Panorama financeiro</p><p className="mt-1 text-xs text-slate-400">Acompanhe seus hábitos mês a mês</p></div><BarChart3 className="size-5 text-sky-400"/></div><div className="mt-5 flex h-28 items-end gap-2">{[34,49,42,65,51,72,59,88,69,82,76,100].map((h,i)=><div key={i} className="flex-1 rounded-t-md bg-gradient-to-t from-blue-700 to-cyan-400 opacity-90" style={{height:`${h}%`}} />)}</div><div className="mt-2 flex justify-between text-[10px] text-slate-500"><span>JAN</span><span>MAR</span><span>MAI</span><span>JUL</span><span>SET</span><span>DEZ</span></div></div>
            <div className="mt-3 grid grid-cols-3 gap-2"><div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3"><WalletCards className="size-4 text-cyan-400"/><span className="text-xs">Lançamentos</span></div><div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3"><Target className="size-4 text-blue-400"/><span className="text-xs">Metas</span></div><div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-3"><FileText className="size-4 text-indigo-400"/><span className="text-xs">Relatórios</span></div></div>
            <p className="mt-3 text-center text-[10px] text-slate-500">Prévia ilustrativa da experiência Zro Finanças</p>
          </div>
        </div>
      </section>
      <section id="recursos" className="border-t border-white/10 py-12 sm:py-16"><div className="mb-8 text-center"><p className="text-sm font-semibold uppercase tracking-[.2em] text-sky-400">Tudo em um só lugar</p><h2 className="mt-3 text-2xl font-bold sm:text-3xl">Mais clareza para cuidar do seu dinheiro</h2></div><div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{FEATURES.map(f=><article key={f.t} className="rounded-2xl border border-white/10 bg-white/[0.035] p-5 transition hover:border-blue-400/30 hover:bg-blue-400/[0.06]"><f.icon className="size-6 text-sky-400"/><h3 className="mt-4 font-semibold">{f.t}</h3><p className="mt-2 text-sm leading-6 text-slate-400">{f.d}</p></article>)}</div></section>
      <section id="sobre" className="grid gap-5 border-t border-white/10 py-8 sm:grid-cols-3 sm:py-10">{[{icon:ShieldCheck,title:"Privacidade",text:"Acesse sua conta com segurança."},{icon:Cloud,title:"Acesse de onde estiver",text:"Use a experiência no computador ou celular."},{icon:Target,title:"Metas para seus sonhos",text:"Transforme planos em objetivos acompanháveis."}].map(item=><div key={item.title} className="flex items-center gap-4 py-2"><item.icon className="size-7 shrink-0 text-sky-400"/><div><h3 className="text-sm font-semibold">{item.title}</h3><p className="mt-1 text-xs text-slate-400">{item.text}</p></div></div>)}</section>
      <footer className="flex flex-col items-center justify-between gap-3 border-t border-white/10 py-6 text-xs text-slate-500 sm:flex-row"><Brand compact/><span>© {new Date().getFullYear()} Zro Finanças. Organize hoje, planeje melhor.</span></footer>
    </main>
  </div>;
}
