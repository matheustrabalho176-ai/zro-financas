create table public.cards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  name text not null,
  credit_limit numeric(12,2) not null default 0,
  closing_day int not null default 1,
  due_day int not null default 10,
  color text not null default 'emerald',
  created_at timestamptz not null default now()
);
create table public.transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  type text not null check (type in ('income','expense')),
  kind text not null default 'variable' check (kind in ('income','fixed','variable','card','saving')),
  description text not null,
  category text not null default 'Outros',
  amount numeric(12,2) not null check (amount >= 0),
  date date not null default current_date,
  paid boolean not null default true,
  card_id uuid references public.cards(id) on delete set null,
  created_at timestamptz not null default now()
);
create table public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  name text not null,
  target numeric(12,2) not null default 0,
  current numeric(12,2) not null default 0,
  deadline date,
  created_at timestamptz not null default now()
);
create table public.budgets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  category text not null,
  amount numeric(12,2) not null default 0,
  created_at timestamptz not null default now(),
  unique (user_id, category)
);
grant select, insert, update, delete on public.cards, public.transactions, public.goals, public.budgets to authenticated;
grant all on public.cards, public.transactions, public.goals, public.budgets to service_role;
alter table public.cards enable row level security;
alter table public.transactions enable row level security;
alter table public.goals enable row level security;
alter table public.budgets enable row level security;
create policy "own cards" on public.cards for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own tx" on public.transactions for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own goals" on public.goals for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own budgets" on public.budgets for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create index on public.transactions (user_id, date);