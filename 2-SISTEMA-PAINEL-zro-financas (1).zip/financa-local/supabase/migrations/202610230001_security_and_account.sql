-- Rode depois do arquivo inicial, no SQL Editor do Supabase.
create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin
  new.updated_at = timezone('utc', now());
  return new;
end;
$$;

revoke all on public.transactions, public.cards, public.goals, public.budgets, public.subscriptions from anon;

alter table public.cards drop constraint if exists cards_color_hex;
alter table public.cards add constraint cards_color_hex check (color ~ '^#[0-9a-fA-F]{6}$') not valid;
alter table public.transactions drop constraint if exists transactions_amount_max;
alter table public.transactions add constraint transactions_amount_max check (amount < 1000000000) not valid;
alter table public.transactions drop constraint if exists transactions_category_len;
alter table public.transactions add constraint transactions_category_len check (char_length(category) between 1 and 100) not valid;

-- Permite que o usuário logado exclua a própria conta e todos os dados.
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid();
begin
  if uid is null then raise exception 'not authenticated'; end if;
  delete from public.transactions where user_id = uid;
  delete from public.budgets where user_id = uid;
  delete from public.goals where user_id = uid;
  delete from public.cards where user_id = uid;
  delete from public.subscriptions where user_id = uid;
  delete from auth.users where id = uid;
end;
$$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
