import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Brand } from "@/components/Brand";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { consumeIdleFlag, touchActivity } from "@/lib/session";

type AuthMode = "in" | "up" | "reset" | "update";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Entrar — Zro Finanças" },
      { name: "description", content: "Acesse sua conta Zro Finanças para controlar suas finanças." },
      { property: "og:title", content: "Entrar — Zro Finanças" },
      { property: "og:description", content: "Acesse sua conta Zro Finanças." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<AuthMode>("in");
  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("mode") === "update") setMode("update");
  }, []);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const recoveryRequested = params.get("mode") === "update";
    // Retorno de login social / link de e-mail: a sessão chega pela URL.
    const returningFromProvider = /access_token|refresh_token|[?&]code=|type=(signup|recovery|magiclink)/.test(window.location.hash + window.location.search);

    if (consumeIdleFlag()) toast.info("Sua sessão foi encerrada após 30 minutos de inatividade. Entre novamente.");

    // O login nunca acontece sozinho: ao abrir esta tela, qualquer sessão antiga é descartada
    // e a pessoa precisa apertar "Entrar".
    if (!recoveryRequested && !returningFromProvider) void supabase.auth.signOut({ scope: "local" });

    const { data } = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") { setMode("update"); return; }
      if (event === "SIGNED_IN" && returningFromProvider && !recoveryRequested) {
        touchActivity();
        navigate({ to: "/dashboard" });
      }
    });
    return () => data.subscription.unsubscribe();
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "reset") {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/auth?mode=update`,
        });
        if (error) toast.error("Não foi possível enviar o e-mail de recuperação. Tente novamente.");
        else {
          toast.success("Se houver uma conta com esse e-mail, você receberá um link para redefinir a senha.");
          setMode("in");
        }
      } else if (mode === "update") {
        const { error } = await supabase.auth.updateUser({ password });
        if (error) toast.error(error.message || "Não foi possível atualizar a senha.");
        else {
          touchActivity();
          toast.success("Senha atualizada com sucesso. Você já pode continuar.");
          setPassword("");
          navigate({ to: "/dashboard" });
        }
      } else if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) toast.error("E-mail ou senha inválidos");
        else { touchActivity(); navigate({ to: "/dashboard" }); }
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: `${window.location.origin}/auth` },
        });
        if (error) toast.error(error.message);
        else if (!data.session) toast.success("Conta criada. Confira seu e-mail para confirmar o cadastro e depois entre.");
        else { toast.success("Conta criada! Bem-vindo."); touchActivity(); navigate({ to: "/dashboard" }); }
      }
    } catch {
      toast.error("Ocorreu um erro inesperado. Verifique sua conexão e tente novamente.");
    } finally {
      setLoading(false);
    }
  }

  async function google() {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: `${window.location.origin}/auth` },
    });
    if (error) toast.error("Não foi possível iniciar o login com Google. Confira a configuração do provedor no Supabase.");
  }

  const title = mode === "in" ? "Bem-vindo de volta" : mode === "up" ? "Crie sua conta" : mode === "reset" ? "Recuperar senha" : "Defina uma nova senha";
  const description = mode === "reset"
    ? "Informe seu e-mail para receber o link de recuperação."
    : mode === "update"
      ? "Escolha uma nova senha para sua conta."
      : "Seu dinheiro organizado, num só lugar.";

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <aside className="auth-aside relative hidden flex-col justify-between overflow-hidden border-r border-border p-12 lg:flex">
        <Brand />
        <div className="max-w-lg">
          <p className="eyebrow">Controle financeiro completo</p>
          <p className="mt-4 text-5xl leading-[1.08] xl:text-6xl" style={{ fontFamily: "var(--font-display)", fontWeight: 500 }}>
            Sua vida financeira com mais <span className="text-primary">clareza, segurança e propósito.</span>
          </p>
          <p className="mt-6 max-w-md text-sm text-muted-foreground">
            Organize seus ganhos, controle seus gastos e planeje o futuro com inteligência e praticidade.
          </p>
        </div>
        <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-muted-foreground">Mais que números, seu futuro</p>
      </aside>
      <div className="grid place-items-center px-4 py-10">
      <div className="glass w-full max-w-md rounded-3xl p-8">
        <div className="mb-8 flex items-center gap-2 lg:hidden">
          <Brand />
        </div>
        <h1 className="text-4xl">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>

        {(mode === "in" || mode === "up") && (
          <>
            <Button variant="outline" className="mt-6 h-11 w-full rounded-xl" onClick={google}>
              Continuar com Google
            </Button>
            <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
              <div className="h-px flex-1 bg-border" /> ou <div className="h-px flex-1 bg-border" />
            </div>
          </>
        )}
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">E-mail</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 rounded-xl" autoComplete="email" />
          </div>
          {mode !== "reset" && (
            <div className="space-y-1.5">
              <Label htmlFor="pw">{mode === "update" ? "Nova senha" : "Senha"}</Label>
              <Input id="pw" type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} className="h-11 rounded-xl" autoComplete={mode === "update" ? "new-password" : mode === "in" ? "current-password" : "new-password"} />
            </div>
          )}
          <Button variant="hero" type="submit" className="h-11 w-full" disabled={loading}>
            {loading ? "Aguarde..." : mode === "in" ? "Entrar" : mode === "up" ? "Criar conta" : mode === "reset" ? "Enviar link de recuperação" : "Salvar nova senha"}
          </Button>
        </form>
        <div className="mt-5 flex flex-col items-center gap-3 text-center text-sm text-muted-foreground">
          {mode === "in" && (
            <button type="button" className="hover:text-primary" onClick={() => setMode("reset")}>Esqueci minha senha</button>
          )}
          {mode === "reset" && (
            <button type="button" className="hover:text-primary" onClick={() => setMode("in")}>Voltar para entrar</button>
          )}
          {mode === "update" && (
            <button type="button" className="hover:text-primary" onClick={() => setMode("in")}>Voltar para o login</button>
          )}
          {(mode === "in" || mode === "up") && (
            <button type="button" className="hover:text-primary" onClick={() => setMode(mode === "in" ? "up" : "in")}>
              {mode === "in" ? "Não tem conta? Cadastre-se" : "Já tem conta? Entrar"}
            </button>
          )}
        </div>
      </div>
      </div>
    </div>
  );
}
