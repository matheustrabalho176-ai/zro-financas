import { createFileRoute, redirect } from "@tanstack/react-router";

// O aplicativo abre diretamente na autenticação. A antiga página de apresentação
// foi preservada em docs/landing-page-prototype.tsx para ser reutilizada depois.
export const Route = createFileRoute("/")({
  beforeLoad: () => {
    throw redirect({ to: "/auth", replace: true });
  },
});
