import { createFileRoute, useRouteContext } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowDownRight, ArrowUpRight, Minus, Plus, TrendingDown, TrendingUp } from "lucide-react";
import { PageHeader } from "@/components/AppShell";
import { MonthPicker } from "@/components/MonthPicker";
import { TransactionDialog } from "@/components/TransactionDialog";
import { Button } from "@/components/ui/button";
import { displayName } from "@/lib/backup";
import { budgetsQuery, byMonth, fmt, goalsQuery, KIND_LABEL, pctChange, summarize, txYearQuery } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Zro Finanças" },
      { name: "description", content: "Visão geral do seu mês: saldo, entradas, gastos e guardado." },
      { property: "og:title", content: "Dashboard — Zro Finanças" },
      { property: "og:description", content: "Visão geral das suas finanças." },
    ],
  }),
  component: Dashboard,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const tooltipStyle = { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12, color: "var(--foreground)" };

function Dashboard() {
  const { user } = useRouteContext({ from: "/_authenticated" });
  const firstName = displayName(user).split(" ")[0];
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const [dlg, setDlg] = useState<null | "income" | "expense">(null);
  const { data: txs = [] } = useQuery(txYearQuery(year));
  const { data: prevYearTxs = [] } = useQuery({ ...txYearQuery(year - 1), enabled: month === 0 });
  const { data: budgets = [] } = useQuery(budgetsQuery);
  const { data: goals = [] } = useQuery(goalsQuery);

  const months = useMemo(() => byMonth(txs), [txs]);
  const cur = months[month]!;
  const prev = month === 0 ? byMonth(prevYearTxs)[11]! : months[month - 1]!;
  const monthTx = txs.filter((t) => Number(t.date.slice(5, 7)) - 1 === month);

  const byCat = useMemo(() => {
    const m = new Map<string, number>();
    monthTx.filter((t) => t.type === "expense" && t.kind !== "saving" && (t.kind !== "fixed" || t.paid) && (t.kind !== "card" || t.paid))
      .forEach((t) => m.set(t.category, (m.get(t.category) ?? 0) + Number(t.amount)));
    return [...m.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [monthTx]);

  const yearTotal = summarize(txs);
  const pendingFixed = monthTx.filter((t) => t.kind === "fixed" && !t.paid);

  const kpis = [
    { label: "Saldo do mês", v: cur.balance, p: prev.balance, good: true, hero: true },
    { label: "Entradas", v: cur.income, p: prev.income, good: true },
    { label: "Gastos fixos", v: cur.fixed, p: prev.fixed, good: false },
    { label: "Gastos variáveis", v: cur.variable, p: prev.variable, good: false },
    { label: "Cartão (faturas)", v: cur.card, p: prev.card, good: false },
    { label: "Guardado", v: cur.saving, p: prev.saving, good: true },
  ];

  return (
    <>
      <PageHeader title={`Olá, ${firstName}`} subtitle="Evolução de saldo, gastos e valor guardado">
        <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); }} />
        <div className="flex w-full min-w-0 gap-2 sm:w-auto">
          <Button variant="outline" className="h-10 min-w-0 flex-1 rounded-xl px-3 sm:flex-none sm:px-4" onClick={() => setDlg("income")}><Plus /> Receita</Button>
          <Button variant="hero" className="h-10 min-w-0 flex-1 rounded-xl px-3 sm:flex-none sm:px-4" onClick={() => setDlg("expense")}><Plus /> Despesa</Button>
        </div>
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {kpis.map((k) => {
          const pct = pctChange(k.v, k.p);
          const up = (pct ?? 0) > 0;
          const positive = pct === null || pct === 0 ? null : up === k.good;
          return (
            <div key={k.label} className={`glass tilt rounded-2xl p-5 ${k.hero ? "ring-1 ring-primary/40 shadow-glow" : ""}`}>
              <p className="text-sm text-muted-foreground">{k.label}</p>
              <p className={`mt-2 font-sans text-3xl font-bold tabular ${k.hero ? "text-gradient" : ""}`}>{fmt(k.v)}</p>
              <p className={`mt-2 flex items-center gap-1 text-xs ${positive === null ? "text-muted-foreground" : positive ? "text-success" : "text-destructive"}`}>
                {pct === null ? <Minus className="size-3" /> : up ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}
                {pct === null ? "sem comparação" : `${up ? "+" : ""}${pct.toFixed(0)}% vs mês anterior`}
              </p>
            </div>
          );
        })}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="glass rounded-2xl p-5 lg:col-span-2">
          <h3 className="font-semibold">Entradas x Gastos — {year}</h3>
          <div className="mt-4 h-72">
            <ResponsiveContainer>
              <AreaChart data={months}>
                <defs>
                  <linearGradient id="gi" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--chart-1)" stopOpacity={0.5} /><stop offset="1" stopColor="var(--chart-1)" stopOpacity={0} /></linearGradient>
                  <linearGradient id="ge" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="var(--chart-4)" stopOpacity={0.4} /><stop offset="1" stopColor="var(--chart-4)" stopOpacity={0} /></linearGradient>
                </defs>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="short" stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `${(v / 1000).toFixed(1)}k`} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => fmt(v)} />
                <Area dataKey="income" name="Entradas" stroke="var(--chart-1)" fill="url(#gi)" strokeWidth={2.5} isAnimationActive animationDuration={1800} animationEasing="ease-out" />
                <Area dataKey="expenses" name="Gastos" stroke="var(--chart-4)" fill="url(#ge)" strokeWidth={2} isAnimationActive animationDuration={2200} animationBegin={250} animationEasing="ease-out" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <h3 className="font-semibold">Gastos por categoria</h3>
          {byCat.length === 0 ? (
            <p className="mt-10 text-center text-sm text-muted-foreground">Sem gastos neste mês.</p>
          ) : (
            <>
              <div className="h-48">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={byCat} dataKey="value" innerRadius={50} outerRadius={80} paddingAngle={3} stroke="none" isAnimationActive animationDuration={1400} animationBegin={150}>
                      {byCat.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie>
                    <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => fmt(v)} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <ul className="space-y-2 text-sm">
                {byCat.slice(0, 5).map((c, i) => (
                  <li key={c.name} className="flex items-center justify-between">
                    <span className="flex items-center gap-2"><span className="size-2.5 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />{c.name}</span>
                    <span className="tabular">{fmt(c.value)}</span>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="glass rounded-2xl p-5">
          <h3 className="font-semibold">Guardado por mês</h3>
          <div className="mt-4 h-48">
            <ResponsiveContainer>
              <BarChart data={months}>
                <XAxis dataKey="short" stroke="var(--muted-foreground)" fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={tooltipStyle} formatter={(v: number) => fmt(v)} cursor={{ fill: "var(--muted)" }} />
                <Bar dataKey="saving" name="Guardado" fill="var(--chart-2)" radius={[6, 6, 0, 0]} isAnimationActive animationDuration={1500} animationBegin={200} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <h3 className="font-semibold">Orçamentos do mês</h3>
          <div className="mt-4 space-y-3">
            {budgets.length === 0 && <p className="text-sm text-muted-foreground">Defina limites em Orçamentos.</p>}
            {budgets.slice(0, 5).map((b) => {
              const spent = byCat.find((c) => c.name === b.category)?.value ?? 0;
              const pct = Math.min(100, (spent / Number(b.amount || 1)) * 100);
              const over = spent > Number(b.amount);
              return (
                <div key={b.id}>
                  <div className="flex justify-between text-sm"><span>{b.category}</span><span className={`tabular ${over ? "text-destructive" : "text-muted-foreground"}`}>{fmt(spent)} / {fmt(Number(b.amount))}</span></div>
                  <div className="mt-1 h-2 rounded-full bg-muted"><div className={`bar-grow h-2 rounded-full ${over ? "bg-destructive" : pct > 80 ? "bg-warning" : "bg-primary"}`} style={{ width: `${pct}%` }} /></div>
                </div>
              );
            })}
          </div>
        </div>
        <div className="glass rounded-2xl p-5">
          <h3 className="font-semibold">Resumo do ano</h3>
          <dl className="mt-4 space-y-2 text-sm">
            <Row l="Entradas" v={yearTotal.income} icon={<TrendingUp className="size-4 text-success" />} />
            <Row l="Total de gastos" v={yearTotal.expenses} icon={<TrendingDown className="size-4 text-destructive" />} />
            <Row l="Guardado" v={yearTotal.saving} />
            <Row l="Gastos ÷ entradas" text={yearTotal.income ? `${((yearTotal.expenses / yearTotal.income) * 100).toFixed(0)}%` : "—"} />
            <Row l="Metas ativas" text={String(goals.length)} />
          </dl>
          {pendingFixed.length > 0 && (
            <div className="mt-4 rounded-xl border border-warning/40 bg-warning/10 p-3 text-xs">
              {pendingFixed.length} conta(s) fixa(s) pendente(s): {fmt(pendingFixed.reduce((s, t) => s + Number(t.amount), 0))}
            </div>
          )}
        </div>
      </div>

      <div className="glass mt-6 rounded-2xl p-5">
        <h3 className="font-semibold">Últimos lançamentos do mês</h3>
        <ul className="mt-3 divide-y divide-border">
          {monthTx.length === 0 && <li className="py-6 text-center text-sm text-muted-foreground">Nenhum lançamento. Comece adicionando uma receita ou despesa.</li>}
          {monthTx.slice(0, 6).map((t) => (
            <li key={t.id} className="flex items-center justify-between py-3 text-sm">
              <div>
                <p className="font-medium">{t.description}</p>
                <p className="text-xs text-muted-foreground">{(KIND_LABEL[t.kind] ?? t.kind)} • {t.category} • {t.date.split("-").reverse().join("/")}</p>
              </div>
              <span className={`tabular font-semibold ${t.type === "income" ? "text-success" : ""}`}>{t.type === "income" ? "+" : "−"}{fmt(Number(t.amount))}</span>
            </li>
          ))}
        </ul>
      </div>

      <TransactionDialog open={dlg !== null} onOpenChange={(o) => !o && setDlg(null)} mode={dlg ?? "expense"} />
    </>
  );
}

function Row({ l, v, text, icon }: { l: string; v?: number; text?: string; icon?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="flex items-center gap-2 text-muted-foreground">{icon}{l}</dt>
      <dd className="tabular font-semibold">{text ?? fmt(v ?? 0)}</dd>
    </div>
  );
}
