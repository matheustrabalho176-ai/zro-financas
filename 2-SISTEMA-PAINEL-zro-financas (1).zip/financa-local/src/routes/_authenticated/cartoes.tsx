import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { lazy, Suspense, useMemo, useState } from "react";
import { toast } from "sonner";
import { Check, MoreVertical, Pencil, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/AppShell";
import { CardWallet, useCardDeck } from "@/components/CardWallet";
import { CategoryTag } from "@/components/CategoryTag";
import { MonthPicker } from "@/components/MonthPicker";
import { TransactionDialog } from "@/components/TransactionDialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cardsQuery, fmt, lastMonths, MONTHS, monthRange, parseInstallment, txYearQuery, type Tx } from "@/lib/finance";

// O gráfico (recharts) é pesado: só é baixado quando a tela de cartões abre.
const InvoiceChart = lazy(() => import("@/components/CardInvoiceChart"));

export const Route = createFileRoute("/_authenticated/cartoes")({
  head: () => ({
    meta: [
      { title: "Cartões — Zro Finanças" },
      { name: "description", content: "Faturas e limites dos seus cartões de crédito." },
      { property: "og:title", content: "Cartões — Zro Finanças" },
      { property: "og:description", content: "Controle de cartões de crédito." },
    ],
  }),
  component: Cards,
});

const brDate = (iso: string) => iso.split("-").reverse().join("/");
const inMonth = (t: Tx, y: number, mo: number) => t.date.startsWith(`${y}-${String(mo + 1).padStart(2, "0")}`);
const sum = (list: Tx[]) => list.reduce((acc, t) => acc + Number(t.amount), 0);

function Cards() {
  const now = new Date();
  const qc = useQueryClient();
  const [year, setYear] = useState(now.getFullYear());
  const [m, setM] = useState(now.getMonth());
  const [editing, setEditing] = useState<Tx | null>(null);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", credit_limit: "", closing_day: "5", due_day: "12" });
  const { data: cards = [] } = useQuery(cardsQuery);
  // Os 12 meses terminando no mês selecionado podem cruzar dois anos.
  const { data: txsCur = [] } = useQuery(txYearQuery(year));
  const { data: txsPrev = [] } = useQuery(txYearQuery(year - 1));
  const isCurrent = year === now.getFullYear() && m === now.getMonth();

  const cardTxs = useMemo(() => [...txsCur, ...txsPrev].filter((t) => t.kind === "card"), [txsCur, txsPrev]);
  const deck = useCardDeck(useMemo(() => cards.map((c) => c.id), [cards]));
  const active = cards.find((c) => c.id === deck.activeId);

  // Tudo abaixo depende só do cartão da frente.
  const activeTxs = useMemo(() => cardTxs.filter((t) => t.card_id === deck.activeId), [cardTxs, deck.activeId]);
  const monthList = useMemo(
    () => activeTxs.filter((t) => inMonth(t, year, m)).sort((a, b) => b.date.localeCompare(a.date) || a.description.localeCompare(b.description)),
    [activeTxs, year, m],
  );
  const monthTotal = sum(monthList);
  const monthPending = sum(monthList.filter((t) => !t.paid));
  const history = useMemo(
    () => lastMonths(year, m, 12).map(({ year: y, month: mo }, i) => ({
      key: `${y}-${mo}`, y, mo, i,
      short: (MONTHS[mo] ?? "").slice(0, 3),
      full: `${MONTHS[mo] ?? ""} de ${y}`,
      total: sum(activeTxs.filter((t) => inMonth(t, y, mo))),
    })),
    [activeTxs, year, m],
  );
  const walletCards = useMemo(
    () => cards.map((c) => ({
      id: c.id, name: c.name, closing_day: c.closing_day, due_day: c.due_day,
      invoice: sum(cardTxs.filter((t) => t.card_id === c.id && inMonth(t, year, m))),
    })),
    [cards, cardTxs, year, m],
  );
  const limit = Number(active?.credit_limit ?? 0);
  const pct = limit ? Math.min(100, (monthTotal / limit) * 100) : 0;
  const range = monthRange(year, m);
  const monthLabel = `${(MONTHS[m] ?? "").slice(0, 3).toLowerCase()}/${String(year).slice(2)}`;

  const add = useMutation({
    mutationFn: async () => {
      if (!f.name.trim()) throw new Error("Informe o nome do cartão");
      const { error } = await supabase.from("cards").insert({
        name: f.name.trim(), credit_limit: Number(f.credit_limit.replace(",", ".")) || 0,
        closing_day: Number(f.closing_day) || 1, due_day: Number(f.due_day) || 10,
      });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Cartão adicionado"); qc.invalidateQueries({ queryKey: ["cards"] }); setOpen(false); setF({ name: "", credit_limit: "", closing_day: "5", due_day: "12" }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const payInvoice = useMutation({
    mutationFn: async ({ cardId, start, end }: { cardId: string; start: string; end: string }) => {
      const { error } = await supabase.from("transactions")
        .update({ paid: true })
        .eq("card_id", cardId).eq("kind", "card").eq("paid", false)
        .gte("date", start).lte("date", end);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Fatura marcada como paga"); qc.invalidateQueries({ queryKey: ["transactions"] }); },
    onError: (e: Error) => toast.error(`Não foi possível pagar a fatura: ${e.message}`),
  });
  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await supabase.from("cards").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["cards"] }),
  });
  const delTx = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("transactions").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Despesa excluída"); qc.invalidateQueries({ queryKey: ["transactions"] }); },
    onError: (e: Error) => toast.error(`Não foi possível excluir: ${e.message}`),
  });

  return (
    <>
      <PageHeader title="Cartões de crédito" subtitle={`Fatura de ${MONTHS[m]} de ${year}`}>
        <MonthPicker year={year} month={m} onChange={(y, mo) => { setYear(y); setM(mo); }} />
        {!isCurrent && <Button variant="outline" className="h-10 rounded-xl" onClick={() => { setYear(now.getFullYear()); setM(now.getMonth()); }}>Mês atual</Button>}
        <Button variant="hero" className="h-10 w-full rounded-xl sm:w-auto" onClick={() => setOpen(true)}><Plus /> Novo cartão</Button>
      </PageHeader>

      {cards.length === 0 && <div className="glass rounded-2xl p-10 text-center text-sm text-muted-foreground">Nenhum cartão cadastrado ainda.</div>}

      {active && (
        <>
          {/* Topo: carteira à esquerda, gráfico à direita (no celular: um embaixo do outro) */}
          <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.25fr)] lg:items-stretch">
            <CardWallet cards={walletCards} order={deck.order} monthLabel={monthLabel} onSelect={deck.select} onNext={deck.next} onPrev={deck.prev} />

            <section className="glass flex min-w-0 flex-col rounded-2xl p-4 sm:p-5" aria-label="Histórico de faturas">
              <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                <h3 className="font-semibold">Faturas dos últimos 12 meses</h3>
                <p className="max-w-full truncate text-xs text-muted-foreground">{active.name} • toque em um ponto para abrir o mês</p>
              </div>
              <div className="relative mt-3 min-h-[220px] flex-1 sm:min-h-[250px]">
                <div className="absolute inset-0">
                  <Suspense fallback={<div className="h-full w-full animate-pulse rounded-xl bg-muted/40" />}>
                    <InvoiceChart data={history} onPick={(y, mo) => { setYear(y); setM(mo); }} />
                  </Suspense>
                </div>
              </div>
            </section>
          </div>

          {/* Abaixo, em largura total: limite e lançamentos do cartão da frente */}
          <section className="glass mt-5 overflow-hidden rounded-2xl" aria-label={`Limite e lançamentos de ${active.name}`}>
            <div className="grid gap-4 border-b border-border p-4 sm:p-5 md:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] md:items-center">
              <div className="min-w-0">
                <div className="flex flex-wrap items-baseline justify-between gap-x-3 text-sm">
                  <span className="text-muted-foreground">Limite usado</span>
                  <span className="tabular">{fmt(monthTotal)} / {fmt(limit)}</span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-muted"><div className={`bar-grow h-2 rounded-full ${pct > 85 ? "bg-destructive" : "bg-primary"}`} style={{ width: `${pct}%` }} /></div>
                <p className="mt-2 text-xs text-muted-foreground">Disponível: <span className="font-semibold text-foreground tabular">{fmt(Math.max(limit - monthTotal, 0))}</span></p>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-2 md:justify-end">
                <div className="min-w-0">
                  <p className="text-xs text-muted-foreground">Fatura de {MONTHS[m]}</p>
                  <p className="font-sans text-xl font-bold tabular text-primary">{fmt(monthTotal)}</p>
                  <p className={`text-xs ${monthPending ? "text-warning" : "text-success"}`}>{monthPending ? `Pendente: ${fmt(monthPending)}` : monthList.length ? "Fatura em dia" : "Sem lançamentos"}</p>
                </div>
                <div className="flex items-center gap-1">
                  {monthPending > 0 && (
                    <Button variant="hero" size="sm" disabled={payInvoice.isPending} onClick={() => {
                      if (confirm(`Confirmar pagamento da fatura de ${active.name} (${MONTHS[m]}) no valor de ${fmt(monthPending)}?`)) {
                        payInvoice.mutate({ cardId: active.id, start: range.start, end: range.end });
                      }
                    }}><Check className="size-4" /> Pagar fatura</Button>
                  )}
                  <Button variant="ghost" size="icon" aria-label="Excluir cartão" onClick={() => confirm(`Excluir o cartão ${active.name}?`) && del.mutate(active.id)}><Trash2 /></Button>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 sm:px-5">
              <div className="min-w-0">
                <h3 className="font-semibold">Lançamentos de {MONTHS[m]} de {year}</h3>
                <p className="text-xs text-muted-foreground">{monthList.length} {monthList.length === 1 ? "lançamento" : "lançamentos"} em {active.name}</p>
              </div>
            </div>

            {monthList.length === 0 ? (
              <p className="px-4 pb-10 pt-4 text-center text-sm text-muted-foreground">Nenhum lançamento neste cartão em {MONTHS[m]}.</p>
            ) : (
              <>
                <div className="hidden overflow-x-auto md:block">
                  <table className="w-full min-w-[640px] text-sm">
                    <thead>
                      <tr className="border-y border-border text-left text-xs uppercase tracking-wide text-muted-foreground">
                        <th className="px-5 py-2.5 font-medium">Data</th>
                        <th className="px-3 py-2.5 font-medium">Categoria</th>
                        <th className="px-3 py-2.5 font-medium">Descrição</th>
                        <th className="px-3 py-2.5 text-right font-medium">Valor</th>
                        <th className="w-12 px-3 py-2.5"><span className="sr-only">Ações</span></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {monthList.map((t) => (
                        <tr key={t.id} className="hover:bg-muted/40">
                          <td className="whitespace-nowrap px-5 py-3 tabular text-muted-foreground">{brDate(t.date)}</td>
                          <td className="px-3 py-3"><CategoryTag category={t.category} /></td>
                          <td className="max-w-[22rem] px-3 py-3"><TxTitle t={t} /></td>
                          <td className="whitespace-nowrap px-3 py-3 text-right font-semibold tabular">{fmt(Number(t.amount))}</td>
                          <td className="px-3 py-3 text-right"><TxActions t={t} onEdit={() => setEditing(t)} onDelete={() => delTx.mutate(t.id)} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <ul className="divide-y divide-border border-t border-border md:hidden">
                  {monthList.map((t) => (
                    <li key={t.id} className="flex items-start gap-2 px-4 py-3">
                      <div className="min-w-0 flex-1 space-y-1.5">
                        <TxTitle t={t} />
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                          <span className="text-xs tabular text-muted-foreground">{brDate(t.date)}</span>
                          <CategoryTag category={t.category} />
                        </div>
                      </div>
                      <span className="shrink-0 pt-0.5 text-sm font-semibold tabular">{fmt(Number(t.amount))}</span>
                      <TxActions t={t} onEdit={() => setEditing(t)} onDelete={() => delTx.mutate(t.id)} />
                    </li>
                  ))}
                </ul>
              </>
            )}
          </section>
        </>
      )}

      <TransactionDialog open={editing !== null} onOpenChange={(o) => { if (!o) setEditing(null); }} mode="expense" editing={editing} />
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader><DialogTitle>Novo cartão</DialogTitle></DialogHeader>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); add.mutate(); }}>
            <div className="space-y-1.5"><Label>Nome</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Ex.: Nubank" /></div>
            <div className="space-y-1.5"><Label>Limite (R$)</Label><Input inputMode="decimal" value={f.credit_limit} onChange={(e) => setF({ ...f, credit_limit: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Dia de fechamento</Label><Input type="number" min={1} max={31} value={f.closing_day} onChange={(e) => setF({ ...f, closing_day: e.target.value })} /></div>
              <div className="space-y-1.5"><Label>Dia de vencimento</Label><Input type="number" min={1} max={31} value={f.due_day} onChange={(e) => setF({ ...f, due_day: e.target.value })} /></div>
            </div>
            <Button variant="hero" type="submit" className="h-11 w-full" disabled={add.isPending}>Salvar</Button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}

/** Descrição + número da parcela (ex.: "Curso Online - 5/10"). */
function TxTitle({ t }: { t: Tx }) {
  const inst = parseInstallment(t.description);
  return (
    <div className="min-w-0">
      <p className="truncate font-medium" title={t.description}>
        {inst ? <>{inst.base} <span className="text-muted-foreground">-</span> <span className="whitespace-nowrap font-semibold text-primary">{inst.number}/{inst.total}</span></> : t.description}
      </p>
      <p className="truncate text-xs text-muted-foreground">
        <span className={t.paid ? "text-success" : "text-warning"}>{t.paid ? "Pago" : "Pendente"}</span>
      </p>
    </div>
  );
}

function TxActions({ t, onEdit, onDelete }: { t: Tx; onEdit: () => void; onDelete: () => void }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="size-9 shrink-0" aria-label={`Ações de ${t.description}`}><MoreVertical /></Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onSelect={onEdit}><Pencil className="size-4" /> Editar</DropdownMenuItem>
        <DropdownMenuItem className="text-destructive focus:text-destructive" onSelect={() => { if (confirm("Excluir esta despesa?")) onDelete(); }}><Trash2 className="size-4" /> Excluir</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
