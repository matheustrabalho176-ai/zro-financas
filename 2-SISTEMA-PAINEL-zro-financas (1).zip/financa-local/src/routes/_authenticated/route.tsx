import { createFileRoute, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { clearActivity, flagIdleLogout, sessionIdleExpired, touchActivity } from "@/lib/session";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getSession();
    if (!data.session) throw redirect({ to: "/auth" });
    // Sessão parada há mais de 30 min (ou sem registro de uso) exige novo login.
    if (sessionIdleExpired()) {
      flagIdleLogout();
      clearActivity();
      await supabase.auth.signOut({ scope: "local" });
      throw redirect({ to: "/auth" });
    }
    touchActivity();
    return { user: data.session.user };
  },
  component: AppShell,
});
