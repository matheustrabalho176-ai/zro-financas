import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Plus, Target, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fmt, goalsQuery, type Goal } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/metas")({
  head: () => ({
    meta: [
      { title: "Metas — Zro Finanças" },
      { name: "description", content: "Acompanhe suas metas de economia." },
      { property: "og:title", content: "Metas — Zro Finanças" },
      { property: "og:description", content: "Metas de economia." },
    ],
  }),
  component: Goals,
});

const num = (s: string) => Number(s.replace(",", ".")) || 0;

function Goals() {
  const qc = useQueryClient();
  const { data: goals = [] } = useQuery(goalsQuery);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", target: "", current: "", deadline: "" });
  const [deposit, setDeposit] = useState<Goal | null>(null);
  const [amt, setAmt] = useState("");
  const inv = () => qc.invalidateQueries({ queryKey: ["goals"] });

  const add = useMutation({
    mutationFn: async () => {
      if (!f.name.trim() || num(f.target) <= 0) throw new Error("Informe nome e valor da meta");
      const { error } = await supabase.from("goals").insert({ name: f.name.trim(), target: num(f.target), current: num(f.current), deadline: f.deadline || null });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Meta criada"); inv(); setOpen(false); setF({ name: "", target: "", current: "", deadline: "" }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const dep = useMutation({
    mutationFn: async () => {
      if (!deposit) return;
      const { error } = await supabase.from("goals").update({ current: Number(deposit.current) + num(amt) }).eq("id", deposit.id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Valor adicionado à meta"); inv(); setDeposit(null); setAmt(""); },
  });
  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await supabase.from("goals").delete().eq("id", id); if (error) throw error; },
    onSuccess: inv,
  });

  return (
    <>
      <PageHeader title="Metas de economia" subtitle="Quanto falta para cada objetivo">
        <Button variant="hero" onClick={() => setOpen(true)}><Plus /> Nova meta</Button>
      </PageHeader>
      {goals.length === 0 && <div className="glass rounded-2xl p-10 text-center text-sm text-muted-foreground">Crie sua primeira meta — viagem, reserva de emergência, carro...</div>}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {goals.map((g) => {
          const pct = Math.min(100, (Number(g.current) / Number(g.target || 1)) * 100);
          return (
            <div key={g.id} className="glass tilt rounded-2xl p-5">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="grid size-10 place-items-center rounded-xl bg-primary/15 text-primary"><Target className="size-5" /></span>
                  <div>
                    <h3 className="font-semibold">{g.name}</h3>
                    {g.deadline && <p className="text-xs text-muted-foreground">até {g.deadline.split("-").reverse().join("/")}</p>}
                  </div>
                </div>
                <Button variant="ghost" size="icon" aria-label="Excluir meta" onClick={() => confirm("Excluir meta?") && del.mutate(g.id)}><Trash2 /></Button>
              </div>
              <p className="mt-5 font-sans text-2xl font-bold tabular">{fmt(Number(g.current))}</p>
              <p className="text-xs text-muted-foreground">de {fmt(Number(g.target))} • {pct.toFixed(0)}%</p>
              <div className="mt-3 h-2.5 rounded-full bg-muted"><div className="bar-grow h-2.5 rounded-full bg-gradient-primary" style={{ width: `${pct}%` }} /></div>
              <Button variant="outline" className="mt-4 w-full rounded-xl" onClick={() => setDeposit(g)}><Plus /> Adicionar valor</Button>
            </div>
          );
        })}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader><DialogTitle>Nova meta</DialogTitle></DialogHeader>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); add.mutate(); }}>
            <div className="space-y-1.5"><Label>Nome</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5"><Label>Valor da meta</Label><Input inputMode="decimal" value={f.target} onChange={(e) => setF({ ...f, target: e.target.value })} /></div>
              <div className="space-y-1.5"><Label>Já guardado</Label><Input inputMode="decimal" value={f.current} onChange={(e) => setF({ ...f, current: e.target.value })} /></div>
            </div>
            <div className="space-y-1.5"><Label>Prazo (opcional)</Label><Input type="date" value={f.deadline} onChange={(e) => setF({ ...f, deadline: e.target.value })} /></div>
            <Button variant="hero" type="submit" className="h-11 w-full" disabled={add.isPending}>Criar meta</Button>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog open={!!deposit} onOpenChange={(o) => !o && setDeposit(null)}>
        <DialogContent className="rounded-2xl sm:max-w-sm">
          <DialogHeader><DialogTitle>Adicionar a {deposit?.name}</DialogTitle></DialogHeader>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); dep.mutate(); }}>
            <Input inputMode="decimal" placeholder="0,00" value={amt} onChange={(e) => setAmt(e.target.value)} autoFocus />
            <Button variant="hero" type="submit" className="h-11 w-full">Adicionar</Button>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
