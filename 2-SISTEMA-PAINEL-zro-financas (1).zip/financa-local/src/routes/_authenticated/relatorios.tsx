import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { CalendarDays, CalendarRange, FileDown } from "lucide-react";
import { PageHeader } from "@/components/AppShell";
import { MonthPicker } from "@/components/MonthPicker";
import { Button } from "@/components/ui/button";
import { byMonth, cardsQuery, fmt, goalsQuery, KIND_LABEL, MONTHS, summarize, txYearQuery } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/relatorios")({
  head: () => ({
    meta: [
      { title: "Relatórios — Zro Finanças" },
      { name: "description", content: "Gere relatórios financeiros em PDF do mês ou do ano." },
      { property: "og:title", content: "Relatórios — Zro Finanças" },
      { property: "og:description", content: "Relatórios em PDF." },
    ],
  }),
  component: Reports,
});

const BLUE: [number, number, number] = [59, 130, 246];

function Reports() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const { data: txs = [] } = useQuery(txYearQuery(year));
  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: goals = [] } = useQuery(goalsQuery);
  const [busy, setBusy] = useState(false);

  async function pdfDoc(title: string) {
    const { jsPDF } = await import("jspdf");
    const autoTable = (await import("jspdf-autotable")).default;
    const doc = new jsPDF();
    doc.setFillColor(15, 23, 20);
    doc.rect(0, 0, 210, 32, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(18);
    doc.text("Zro Finanças", 14, 15);
    doc.setFontSize(11);
    doc.text(title, 14, 24);
    doc.setFontSize(8);
    doc.text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, 196, 24, { align: "right" });
    doc.setTextColor(0, 0, 0);
    return { doc, autoTable };
  }

  async function monthly() {
    setBusy(true);
    const list = txs.filter((t) => Number(t.date.slice(5, 7)) - 1 === month).sort((a, b) => a.date.localeCompare(b.date));
    const s = summarize(list);
    const { doc, autoTable } = await pdfDoc(`Relatório mensal — ${MONTHS[month]!} ${year}`);
    autoTable(doc, {
      startY: 40, theme: "grid", headStyles: { fillColor: BLUE },
      head: [["Indicador", "Valor"]],
      body: [["Entradas", fmt(s.income)], ["Gastos fixos (pagos)", fmt(s.fixed)], ["Gastos variáveis", fmt(s.variable)], ["Cartão (faturas)", fmt(s.card)], ["Total de gastos", fmt(s.expenses)], ["Guardado", fmt(s.saving)], ["Saldo do mês", fmt(s.balance)]],
    });
    const cats = new Map<string, number>();
    list.filter((t) => t.type === "expense" && t.kind !== "saving").forEach((t) => cats.set(t.category, (cats.get(t.category) ?? 0) + Number(t.amount)));
    autoTable(doc, {
      theme: "striped", headStyles: { fillColor: BLUE },
      head: [["Categoria", "Total"]],
      body: [...cats.entries()].sort((a, b) => b[1] - a[1]).map(([c, v]) => [c, fmt(v)]),
    });
    autoTable(doc, {
      theme: "striped", headStyles: { fillColor: BLUE }, styles: { fontSize: 8 },
      head: [["Data", "Descrição", "Tipo", "Categoria", "Status", "Valor"]],
      body: list.map((t) => [t.date.split("-").reverse().join("/"), t.description, (KIND_LABEL[t.kind] ?? t.kind), t.category,
        t.kind === "fixed" || t.kind === "card" ? (t.paid ? "Pago" : "Pendente") : "—",
        `${t.type === "income" ? "+" : "-"} ${fmt(Number(t.amount))}`]),
    });
    doc.save(`relatorio-${MONTHS[month]!.toLowerCase()}-${year}.pdf`);
    setBusy(false);
  }

  async function annual() {
    setBusy(true);
    const months = byMonth(txs);
    const total = summarize(txs);
    const { doc, autoTable } = await pdfDoc(`Relatório anual — ${year}`);
    autoTable(doc, {
      startY: 40, theme: "grid", headStyles: { fillColor: BLUE }, styles: { fontSize: 8 },
      head: [["Mês", "Entradas", "Saldo", "Fixos", "Variáveis", "Cartão", "Total gastos", "Guardado", "Gastos ÷ entr."]],
      body: [
        ...months.map((m) => [m.name, fmt(m.income), fmt(m.balance), fmt(m.fixed), fmt(m.variable), fmt(m.card), fmt(m.expenses), fmt(m.saving), m.income ? `${((m.expenses / m.income) * 100).toFixed(0)}%` : "0%"]),
        ["Total", fmt(total.income), "", fmt(total.fixed), fmt(total.variable), fmt(total.card), fmt(total.expenses), fmt(total.saving), total.income ? `${((total.expenses / total.income) * 100).toFixed(0)}%` : "0%"],
      ],
    });
    if (cards.length) autoTable(doc, {
      theme: "striped", headStyles: { fillColor: BLUE },
      head: [["Cartão", "Limite", "Total no ano"]],
      body: cards.map((c) => [c.name, fmt(Number(c.credit_limit)), fmt(txs.filter((t) => t.card_id === c.id).reduce((s, t) => s + Number(t.amount), 0))]),
    });
    if (goals.length) autoTable(doc, {
      theme: "striped", headStyles: { fillColor: BLUE },
      head: [["Meta", "Guardado", "Objetivo", "Progresso"]],
      body: goals.map((g) => [g.name, fmt(Number(g.current)), fmt(Number(g.target)), `${((Number(g.current) / Number(g.target || 1)) * 100).toFixed(0)}%`]),
    });
    doc.save(`relatorio-anual-${year}.pdf`);
    setBusy(false);
  }

  const s = summarize(txs.filter((t) => Number(t.date.slice(5, 7)) - 1 === month));

  return (
    <>
      <PageHeader title="Relatórios em PDF" subtitle="Baixe um resumo profissional das suas finanças">
        <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); }} />
      </PageHeader>
      <div className="grid gap-5 md:grid-cols-2">
        <div className="glass tilt rounded-2xl p-6">
          <CalendarDays className="size-7 text-primary" />
          <h3 className="mt-4 text-lg font-semibold">Relatório mensal</h3>
          <p className="mt-1 text-sm text-muted-foreground">Indicadores, gastos por categoria e todos os lançamentos de {MONTHS[month]!} {year}.</p>
          <p className="mt-4 text-sm">Saldo: <span className="font-semibold tabular text-primary">{fmt(s.balance)}</span></p>
          <Button variant="hero" className="mt-5 w-full" disabled={busy} onClick={monthly}><FileDown /> Baixar PDF do mês</Button>
        </div>
        <div className="glass tilt rounded-2xl p-6">
          <CalendarRange className="size-7 text-info" />
          <h3 className="mt-4 text-lg font-semibold">Relatório anual</h3>
          <p className="mt-1 text-sm text-muted-foreground">Tabela mês a mês de {year} (como na sua planilha), cartões e metas.</p>
          <p className="mt-4 text-sm">Entradas no ano: <span className="font-semibold tabular">{fmt(summarize(txs).income)}</span></p>
          <Button variant="outline" className="mt-5 w-full rounded-xl" disabled={busy} onClick={annual}><FileDown /> Baixar PDF do ano</Button>
        </div>
      </div>
    </>
  );
}
