import { clearActivity } from "@/lib/session";
import { createFileRoute, useNavigate, useRouteContext } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Download, KeyRound, LogOut, ShieldCheck, Trash2, Upload, UserRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { displayName, exportBackup, importBackup } from "@/lib/backup";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => ({
    meta: [
      { title: "Meu perfil — Zro Finanças" },
      { name: "description", content: "Gerencie seu usuário, sua senha, seus backups e sua conta." },
    ],
  }),
  component: Profile,
});

const USERNAME_RE = /^[\p{L}\p{N}][\p{L}\p{N} ._-]{1,29}$/u;

function Section({ icon: Icon, title, description, children }: { icon: typeof UserRound; title: string; description?: string; children: React.ReactNode }) {
  return (
    <section className="glass rounded-2xl p-5 sm:p-6">
      <div className="mb-5 flex items-start gap-3">
        <span className="grid size-10 shrink-0 place-items-center rounded-xl border border-primary/30 bg-primary/[0.06] text-primary"><Icon className="size-5" /></span>
        <div className="min-w-0">
          <h2 className="text-2xl leading-tight">{title}</h2>
          {description && <p className="mt-0.5 text-sm text-muted-foreground">{description}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

function Profile() {
  const { user } = useRouteContext({ from: "/_authenticated" });
  const qc = useQueryClient();
  const navigate = useNavigate();
  const name = displayName(user);
  const providers: string[] = (user.app_metadata?.["providers"] as string[] | undefined) ?? [];
  const hasPassword = providers.length === 0 || providers.includes("email");

  /* ---------- usuário ---------- */
  const [username, setUsername] = useState(name);
  const [savingName, setSavingName] = useState(false);
  const usernameChanged = username.trim() !== name;

  async function saveUsername(e: React.FormEvent) {
    e.preventDefault();
    const value = username.trim().replace(/\s+/g, " ");
    if (!USERNAME_RE.test(value)) {
      toast.error("Use de 2 a 30 caracteres: letras, números, espaço, ponto, hífen ou sublinhado.");
      return;
    }
    setSavingName(true);
    const { error } = await supabase.auth.updateUser({ data: { username: value } });
    setSavingName(false);
    if (error) { toast.error(error.message || "Não foi possível atualizar o usuário."); return; }
    setUsername(value);
    toast.success("Usuário atualizado.");
  }

  /* ---------- senha ---------- */
  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [savingPw, setSavingPw] = useState(false);

  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    if (pw.next.length < 8) { toast.error("A nova senha precisa ter ao menos 8 caracteres."); return; }
    if (pw.next !== pw.confirm) { toast.error("A confirmação não confere com a nova senha."); return; }
    if (hasPassword && pw.next === pw.current) { toast.error("A nova senha deve ser diferente da atual."); return; }
    setSavingPw(true);
    try {
      if (hasPassword) {
        // Reautentica para garantir que quem está trocando a senha conhece a atual.
        const { error } = await supabase.auth.signInWithPassword({ email: user.email!, password: pw.current });
        if (error) { toast.error("A senha atual está incorreta."); return; }
      }
      const { error } = await supabase.auth.updateUser({ password: pw.next });
      if (error) { toast.error(error.message || "Não foi possível alterar a senha."); return; }
      setPw({ current: "", next: "", confirm: "" });
      toast.success("Senha alterada com sucesso.");
    } finally {
      setSavingPw(false);
    }
  }

  /* ---------- backup ---------- */
  const fileInput = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function doExport() {
    setBusy(true);
    try { await exportBackup(); toast.success("Backup exportado com sucesso."); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Não foi possível exportar os dados."); }
    finally { setBusy(false); }
  }
  async function doImport(file?: File) {
    if (!file) return;
    setBusy(true);
    try {
      const r = await importBackup(file);
      await qc.invalidateQueries();
      toast.success(`Importação concluída: ${r.transactions} lançamentos, ${r.cards} cartões, ${r.goals} metas e ${r.budgets} orçamentos.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível importar o backup.");
    } finally {
      setBusy(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  /* ---------- sessão e exclusão ---------- */
  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    clearActivity();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const [delOpen, setDelOpen] = useState(false);
  const [delText, setDelText] = useState("");
  const [deleting, setDeleting] = useState(false);

  async function deleteAccount() {
    if (delText !== "EXCLUIR") return;
    setDeleting(true);
    try {
      const { error } = await supabase.rpc("delete_my_account" as never);
      if (error) throw error;
      qc.clear();
      clearActivity();
    await supabase.auth.signOut();
      toast.success("Sua conta foi excluída.");
      navigate({ to: "/", replace: true });
    } catch {
      toast.error("Não foi possível excluir a conta. Tente novamente.");
      setDeleting(false);
    }
  }

  const since = user.created_at ? new Date(user.created_at).toLocaleDateString("pt-BR", { month: "long", year: "numeric" }) : null;

  return (
    <>
      <PageHeader title="Meu perfil" subtitle="Seus dados de acesso, segurança e backups" />

      <div className="glass mb-6 flex flex-col items-start gap-5 rounded-2xl p-5 sm:flex-row sm:items-center sm:p-6">
        <span className="avatar-ring"><Avatar name={name} className="size-20 text-2xl" /></span>
        <div className="min-w-0">
          <p className="eyebrow">Conta</p>
          <p className="mt-1 truncate font-display text-3xl font-semibold">{name}</p>
          <p className="truncate text-sm text-muted-foreground">{user.email}</p>
          {since && <p className="mt-1 text-xs text-muted-foreground">Membro desde {since}</p>}
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Section icon={UserRound} title="Usuário" description="O nome que aparece no sistema. O login continua sendo pelo e-mail.">
          <form onSubmit={saveUsername} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username">Nome de usuário</Label>
              <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)} maxLength={30} autoComplete="username" className="h-11 rounded-xl" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="email">E-mail</Label>
              <Input id="email" value={user.email ?? ""} readOnly disabled className="h-11 rounded-xl" />
            </div>
            <Button type="submit" variant="hero" className="h-11 px-6" disabled={savingName || !usernameChanged}>
              {savingName ? "Salvando..." : "Salvar usuário"}
            </Button>
          </form>
        </Section>

        <Section icon={KeyRound} title="Senha" description={hasPassword ? "Para sua segurança, confirme a senha atual antes de trocar." : "Sua conta entra pelo Google. Você pode criar uma senha para também entrar por e-mail."}>
          <form onSubmit={savePassword} className="space-y-4">
            {hasPassword && (
              <div className="space-y-1.5">
                <Label htmlFor="pw-current">Senha atual</Label>
                <Input id="pw-current" type="password" required value={pw.current} onChange={(e) => setPw({ ...pw, current: e.target.value })} autoComplete="current-password" className="h-11 rounded-xl" />
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="pw-next">Nova senha</Label>
              <Input id="pw-next" type="password" required minLength={8} value={pw.next} onChange={(e) => setPw({ ...pw, next: e.target.value })} autoComplete="new-password" className="h-11 rounded-xl" />
              <p className="text-xs text-muted-foreground">Mínimo de 8 caracteres.</p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pw-confirm">Confirmar nova senha</Label>
              <Input id="pw-confirm" type="password" required minLength={8} value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} autoComplete="new-password" className="h-11 rounded-xl" />
            </div>
            <Button type="submit" variant="hero" className="h-11 px-6" disabled={savingPw}>
              {savingPw ? "Salvando..." : "Alterar senha"}
            </Button>
          </form>
        </Section>

        <Section icon={ShieldCheck} title="Backup e transferência" description="Baixe uma cópia dos seus dados ou importe um backup do Zro Finanças.">
          <div className="grid grid-cols-2 gap-3">
            <Button variant="outline" className="h-11 rounded-xl" disabled={busy} onClick={doExport}><Download /> Exportar</Button>
            <Button variant="outline" className="h-11 rounded-xl" disabled={busy} onClick={() => fileInput.current?.click()}><Upload /> Importar</Button>
          </div>
          <input ref={fileInput} type="file" accept="application/json,.json" className="hidden" onChange={(e) => void doImport(e.target.files?.[0])} />
          <p className="mt-3 text-xs text-muted-foreground">A importação soma os dados do arquivo aos que você já tem. Ela não apaga nada.</p>
        </Section>

        <Section icon={LogOut} title="Sessão e conta" description="Saia deste aparelho ou exclua sua conta de forma definitiva.">
          <Button variant="outline" className="h-11 w-full justify-start rounded-xl" onClick={signOut}><LogOut /> Sair da conta</Button>
          <div className="mt-5 rounded-xl border border-destructive/30 bg-destructive/[0.06] p-4">
            <p className="text-sm font-semibold text-destructive">Zona de risco</p>
            <p className="mt-1 text-xs text-muted-foreground">Excluir apaga sua conta e todos os seus lançamentos, cartões, metas e orçamentos para sempre.</p>
            <Button variant="outline" className="mt-3 border-destructive/50 bg-transparent text-destructive hover:border-destructive hover:bg-destructive/10" onClick={() => { setDelText(""); setDelOpen(true); }}>
              <Trash2 /> Excluir minha conta
            </Button>
          </div>
        </Section>
      </div>

      <AlertDialog open={delOpen} onOpenChange={(o) => !deleting && setDelOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir sua conta?</AlertDialogTitle>
            <AlertDialogDescription>Isso apaga sua conta e TODOS os seus dados para sempre. Se quiser guardar uma cópia, exporte um backup antes. Para confirmar, digite EXCLUIR.</AlertDialogDescription>
          </AlertDialogHeader>
          <Input value={delText} onChange={(e) => setDelText(e.target.value)} placeholder="EXCLUIR" aria-label="Digite EXCLUIR para confirmar" autoComplete="off" className="h-11 rounded-xl" />
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
            <Button variant="destructive" disabled={delText !== "EXCLUIR" || deleting} onClick={deleteAccount}>
              {deleting ? "Excluindo..." : "Excluir definitivamente"}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
