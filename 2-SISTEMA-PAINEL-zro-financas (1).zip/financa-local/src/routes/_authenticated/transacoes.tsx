import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Check, FileUp, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/AppShell";
import { MonthPicker } from "@/components/MonthPicker";
import { TransactionDialog } from "@/components/TransactionDialog";
import { StatementImportDialog } from "@/components/StatementImportDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { fmt, KIND_LABEL, summarize, txYearQuery, type Tx } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/transacoes")({
  head: () => ({
    meta: [
      { title: "Lançamentos — Zro Finanças" },
      { name: "description", content: "Todas as suas receitas e despesas do mês." },
      { property: "og:title", content: "Lançamentos — Zro Finanças" },
      { property: "og:description", content: "Receitas e despesas do mês." },
    ],
  }),
  component: Transactions,
});

const FILTERS = [["all", "Todos"], ["income", "Entradas"], ["fixed", "Fixos"], ["variable", "Variáveis"], ["card", "Cartão"], ["saving", "Guardado"]] as const;

function Transactions() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const [filter, setFilter] = useState<string>("all");
  const [q, setQ] = useState("");
  const [dlg, setDlg] = useState<null | "income" | "expense">(null);
  const [editing, setEditing] = useState<Tx | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const qc = useQueryClient();
  const { data: txs = [], isLoading } = useQuery(txYearQuery(year));

  const monthTx = txs.filter((t) => Number(t.date.slice(5, 7)) - 1 === month);
  const list = monthTx.filter((t) => (filter === "all" || t.kind === filter) && t.description.toLowerCase().includes(q.toLowerCase()));
  const s = summarize(monthTx);

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("transactions").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Removido"); qc.invalidateQueries({ queryKey: ["transactions"] }); },
  });
  const togglePaid = useMutation({
    mutationFn: async (t: Tx) => {
      const { error } = await supabase.from("transactions").update({ paid: !t.paid }).eq("id", t.id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["transactions"] }),
  });

  return (
    <>
      <PageHeader title="Lançamentos" subtitle={`Saldo do mês: ${fmt(s.balance)}`}>
        <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); }} />
        <Button variant="outline" className="h-10 w-full rounded-xl sm:w-auto" onClick={() => setImportOpen(true)}><FileUp className="mr-2 size-4" /> Importar extrato PDF</Button>
        <div className="flex w-full min-w-0 gap-2 sm:w-auto">
          <Button variant="outline" className="h-10 min-w-0 flex-1 rounded-xl px-3 sm:flex-none sm:px-4" onClick={() => { setEditing(null); setDlg("income"); }}><Plus /> Receita</Button>
          <Button variant="hero" className="h-10 min-w-0 flex-1 rounded-xl px-3 sm:flex-none sm:px-4" onClick={() => { setEditing(null); setDlg("expense"); }}><Plus /> Despesa</Button>
        </div>
      </PageHeader>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {FILTERS.map(([k, l]) => (
          <button key={k} onClick={() => setFilter(k)}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium ${filter === k ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-muted"}`}>
            {l}
          </button>
        ))}
        <div className="relative ml-auto w-full sm:w-64">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input className="rounded-xl pl-9" placeholder="Buscar..." value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>

      <div className="glass overflow-hidden rounded-2xl">
        {isLoading ? <p className="p-8 text-center text-sm text-muted-foreground">Carregando...</p> :
          list.length === 0 ? <p className="p-10 text-center text-sm text-muted-foreground">Nenhum lançamento encontrado.</p> : (
          <ul className="divide-y divide-border">
            {list.map((t) => (
              <li key={t.id} className="flex items-center gap-3 px-4 py-3 text-sm hover:bg-muted/40">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{t.description}</p>
                  <p className="text-xs text-muted-foreground">{(KIND_LABEL[t.kind] ?? t.kind)} • {t.category} • {t.date.split("-").reverse().join("/")}</p>
                </div>
                {(t.kind === "fixed" || t.kind === "card") && (
                  <button onClick={() => togglePaid.mutate(t)}
                    className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium ${t.paid ? "bg-primary/15 text-primary" : "bg-warning/15 text-warning"}`}>
                    {t.paid && <Check className="size-3" />}{t.paid ? "Pago" : "Pendente"}
                  </button>
                )}
                <span className={`w-28 text-right font-semibold tabular ${t.type === "income" ? "text-success" : ""}`}>
                  {t.type === "income" ? "+" : "−"}{fmt(Number(t.amount))}
                </span>
                <Button variant="ghost" size="icon" aria-label="Editar" onClick={() => { setEditing(t); setDlg(t.type === "income" ? "income" : "expense"); }}><Pencil /></Button>
                <Button variant="ghost" size="icon" aria-label="Excluir" onClick={() => confirm("Excluir este lançamento?") && del.mutate(t.id)}><Trash2 /></Button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <StatementImportDialog open={importOpen} onOpenChange={setImportOpen} />
      <TransactionDialog open={dlg !== null} onOpenChange={(o) => { if (!o) { setDlg(null); setEditing(null); } }} mode={dlg ?? "expense"} editing={editing} />
    </>
  );
}
