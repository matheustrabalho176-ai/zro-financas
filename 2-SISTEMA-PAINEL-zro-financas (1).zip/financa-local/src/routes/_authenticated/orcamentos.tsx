import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { AlertTriangle, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/AppShell";
import { MonthPicker } from "@/components/MonthPicker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { budgetsQuery, EXPENSE_CATEGORIES, fmt, txYearQuery } from "@/lib/finance";

export const Route = createFileRoute("/_authenticated/orcamentos")({
  head: () => ({
    meta: [
      { title: "Orçamentos — Zro Finanças" },
      { name: "description", content: "Limites mensais de gasto por categoria." },
      { property: "og:title", content: "Orçamentos — Zro Finanças" },
      { property: "og:description", content: "Orçamento por categoria." },
    ],
  }),
  component: Budgets,
});

function Budgets() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const qc = useQueryClient();
  const { data: budgets = [] } = useQuery(budgetsQuery);
  const { data: txs = [] } = useQuery(txYearQuery(year));
  const [cat, setCat] = useState<string>("Moradia");
  const [amount, setAmount] = useState("");

  const upsert = useMutation({
    mutationFn: async () => {
      const v = Number(amount.replace(",", "."));
      if (!(v > 0)) throw new Error("Informe um valor");
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("budgets").upsert({ user_id: u.user!.id, category: cat, amount: v }, { onConflict: "user_id,category" });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Orçamento salvo"); setAmount(""); qc.invalidateQueries({ queryKey: ["budgets"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const del = useMutation({
    mutationFn: async (id: string) => { const { error } = await supabase.from("budgets").delete().eq("id", id); if (error) throw error; },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["budgets"] }),
  });

  const spentBy = (c: string) => txs
    .filter((t) => Number(t.date.slice(5, 7)) - 1 === month && t.type === "expense" && t.kind !== "saving" && t.category === c && (t.kind !== "fixed" || t.paid) && (t.kind !== "card" || t.paid))
    .reduce((s, t) => s + Number(t.amount), 0);

  return (
    <>
      <PageHeader title="Orçamento por categoria" subtitle="Defina limites e receba alertas ao se aproximar">
        <MonthPicker year={year} month={month} onChange={(y, m) => { setYear(y); setMonth(m); }} />
      </PageHeader>
      <form className="glass mb-6 flex flex-wrap items-end gap-3 rounded-2xl p-4" onSubmit={(e) => { e.preventDefault(); upsert.mutate(); }}>
        <div className="w-full sm:w-56">
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{EXPENSE_CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <Input className="w-full sm:w-40" inputMode="decimal" placeholder="Limite R$" value={amount} onChange={(e) => setAmount(e.target.value)} />
        <Button variant="hero" type="submit"><Plus /> Salvar limite</Button>
      </form>
      {budgets.length === 0 && <div className="glass rounded-2xl p-10 text-center text-sm text-muted-foreground">Nenhum orçamento definido.</div>}
      <div className="grid gap-4 md:grid-cols-2">
        {budgets.map((b) => {
          const spent = spentBy(b.category);
          const lim = Number(b.amount);
          const pct = (spent / (lim || 1)) * 100;
          const state = pct >= 100 ? "over" : pct >= 80 ? "warn" : "ok";
          return (
            <div key={b.id} className="glass tilt rounded-2xl p-5">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{b.category}</h3>
                <Button variant="ghost" size="icon" aria-label="Excluir" onClick={() => del.mutate(b.id)}><Trash2 /></Button>
              </div>
              <p className="mt-2 text-sm tabular text-muted-foreground"><span className="text-xl font-bold text-foreground">{fmt(spent)}</span> de {fmt(lim)}</p>
              <div className="mt-3 h-2.5 rounded-full bg-muted">
                <div className={`bar-grow h-2.5 rounded-full ${state === "over" ? "bg-destructive" : state === "warn" ? "bg-warning" : "bg-primary"}`} style={{ width: `${Math.min(100, pct)}%` }} />
              </div>
              <p className={`mt-2 flex items-center gap-1 text-xs ${state === "over" ? "text-destructive" : state === "warn" ? "text-warning" : "text-muted-foreground"}`}>
                {state !== "ok" && <AlertTriangle className="size-3" />}
                {state === "over" ? `Estourou ${fmt(spent - lim)}` : state === "warn" ? `Atenção: ${pct.toFixed(0)}% usado` : `Restam ${fmt(lim - spent)}`}
              </p>
            </div>
          );
        })}
      </div>
    </>
  );
}
