import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";
import { supabase as localSupabase } from "./local-client";

const url = import.meta.env["VITE_SUPABASE_URL"]?.trim();
const key = import.meta.env["VITE_SUPABASE_PUBLISHABLE_KEY"]?.trim();
const isConfigured = Boolean(url && key && /^https:\/\//i.test(url) && !/localhost|127\.0\.0\.1/i.test(url) && key !== "local");

if (!isConfigured && import.meta.env.PROD) {
  // Never ship the localStorage-based demo authentication in a production deployment.
  throw new Error(
    "Zro Finanças não foi configurado: defina VITE_SUPABASE_URL e VITE_SUPABASE_PUBLISHABLE_KEY nas variáveis de ambiente da hospedagem."
  );
}

/**
 * Real Supabase client whenever cloud credentials are configured.
 * The local adapter is only a development/demo fallback and must never be deployed.
 */
export const supabase = isConfigured
  ? createClient<Database>(url!, key!, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : localSupabase;

export const isCloudConfigured = isConfigured;
