// VERSÃO LOCAL: substitui o Lovable Cloud. Todos os dados ficam salvos
// no navegador deste computador (localStorage). Mesma interface usada pelo app.
type Row = Record<string, any>;
const isBrowser = typeof window !== "undefined";
const DB = "financa_local_db";
const SESSION = "financa_local_session";
const USERS = "financa_local_users";

function load(): Record<string, Row[]> { if (!isBrowser) return {}; try { return JSON.parse(localStorage.getItem(DB) || "{}"); } catch { return {}; } }
function save(db: Record<string, Row[]>) { if (isBrowser) localStorage.setItem(DB, JSON.stringify(db)); }
function uid() { return (globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now()); }
function currentUser(): any { if (!isBrowser) return null; try { return JSON.parse(localStorage.getItem(SESSION) || "null"); } catch { return null; } }

type Filter = (r: Row) => boolean;
class Query implements PromiseLike<any> {
  private filters: Filter[] = [];
  private orders: { col: string; asc: boolean }[] = [];
  private op: "select" | "insert" | "update" | "delete" | "upsert" = "select";
  private payload: any; private conflict?: string[]; private one = false; private offset = 0; private end?: number;
  constructor(private table: string) {}
  select(_c?: string) { return this; }
  insert(v: any) { this.op = "insert"; this.payload = v; return this; }
  update(v: any) { this.op = "update"; this.payload = v; return this; }
  delete() { this.op = "delete"; return this; }
  upsert(v: any, o?: { onConflict?: string }) { this.op = "upsert"; this.payload = v; this.conflict = o?.onConflict?.split(",").map((s) => s.trim()); return this; }
  eq(c: string, v: any) { this.filters.push((r) => r[c] === v); return this; }
  neq(c: string, v: any) { this.filters.push((r) => r[c] !== v); return this; }
  gte(c: string, v: any) { this.filters.push((r) => r[c] >= v); return this; }
  lte(c: string, v: any) { this.filters.push((r) => r[c] <= v); return this; }
  gt(c: string, v: any) { this.filters.push((r) => r[c] > v); return this; }
  lt(c: string, v: any) { this.filters.push((r) => r[c] < v); return this; }
  in(c: string, v: any[]) { this.filters.push((r) => v.includes(r[c])); return this; }
  order(c: string, o?: { ascending?: boolean }) { this.orders.push({ col: c, asc: o?.ascending !== false }); return this; }
  limit(n: number) { this.end = this.offset + Math.max(0, n) - 1; return this; }
  range(from: number, to: number) { this.offset = Math.max(0, from); this.end = Math.max(this.offset - 1, to); return this; }
  single() { this.one = true; return this; }
  maybeSingle() { this.one = true; return this; }
  private run() {
    const user = currentUser();
    if (!user) return { data: null, error: { message: "Não autenticado" } };
    const db = load(); const all = db[this.table] ?? [];
    const mine = (r: Row) => r.user_id === user.id && this.filters.every((f) => f(r));
    const now = new Date().toISOString();
    const fill = (v: Row) => ({ id: uid(), created_at: now, updated_at: now, ...v, user_id: user.id });
    let out: Row[] = [];
    if (this.op === "select") {
      out = all.filter(mine);
      for (const o of [...this.orders].reverse()) out.sort((a, b) => (a[o.col] > b[o.col] ? 1 : a[o.col] < b[o.col] ? -1 : 0) * (o.asc ? 1 : -1));
      if (this.end !== undefined) out = out.slice(this.offset, this.end + 1);
    } else if (this.op === "insert") {
      out = (Array.isArray(this.payload) ? this.payload : [this.payload]).map(fill); db[this.table] = [...all, ...out];
    } else if (this.op === "update") {
      db[this.table] = all.map((r) => (mine(r) ? (out.push({ ...r, ...this.payload, updated_at: now }), out[out.length - 1]) : r));
    } else if (this.op === "delete") {
      out = all.filter(mine); db[this.table] = all.filter((r) => !mine(r));
    } else {
      const keys = this.conflict ?? ["id"]; const list = [...all];
      for (const v of Array.isArray(this.payload) ? this.payload : [this.payload]) {
        const row = fill(v);
        const i = list.findIndex((r) => keys.every((k) => r[k] === row[k]));
        if (i >= 0) list[i] = { ...list[i], ...v, user_id: user.id, updated_at: now }; else list.push(row);
        out.push(i >= 0 ? list[i] : row);
      }
      db[this.table] = list;
    }
    if (this.op !== "select") save(db);
    return { data: this.one ? out[0] ?? null : out, error: null };
  }
  then<A = any, B = never>(ok?: ((v: any) => A | PromiseLike<A>) | null, err?: ((e: any) => B | PromiseLike<B>) | null) {
    return Promise.resolve().then(() => this.run()).then(ok, err);
  }
}

type Listener = (event: string, session: any) => void;
const listeners = new Set<Listener>();
const emit = (e: string) => { const u = currentUser(); listeners.forEach((l) => l(e, u ? { user: u } : null)); };
const users = (): Record<string, { password: string; user: any }> => { try { return JSON.parse(localStorage.getItem(USERS) || "{}"); } catch { return {}; } };

export const supabase: any = {
  from: (t: string) => new Query(t),
  auth: {
    async getUser() { return { data: { user: currentUser() }, error: null }; },
    async getSession() { const u = currentUser(); return { data: { session: u ? { user: u, access_token: "local" } : null }, error: null }; },
    onAuthStateChange(cb: Listener) { listeners.add(cb); return { data: { subscription: { unsubscribe: () => listeners.delete(cb) } } }; },
    async signUp({ email, password, options }: any) {
      const all = users(); const key = String(email).toLowerCase();
      if (all[key]) return { data: null, error: { message: "Este e-mail já está cadastrado." } };
      const user = { id: uid(), email: key, user_metadata: options?.data ?? {} };
      all[key] = { password, user }; localStorage.setItem(USERS, JSON.stringify(all));
      localStorage.setItem(SESSION, JSON.stringify(user)); emit("SIGNED_IN");
      return { data: { user, session: { user } }, error: null };
    },
    async signInWithPassword({ email, password }: any) {
      const rec = users()[String(email).toLowerCase()];
      if (!rec || rec.password !== password) return { data: null, error: { message: "E-mail ou senha incorretos." } };
      localStorage.setItem(SESSION, JSON.stringify(rec.user)); emit("SIGNED_IN");
      return { data: { user: rec.user, session: { user: rec.user } }, error: null };
    },
    async signInWithOAuth(_options?: any) { return { data: null, error: { message: "Login OAuth exige configurar o Supabase real." } }; },
    async resetPasswordForEmail(_email?: string, _options?: any) { return { data: null, error: { message: "Recuperação de senha exige configurar o Supabase real." } }; },
    async signOut() { localStorage.removeItem(SESSION); emit("SIGNED_OUT"); return { error: null }; },
    // Atualiza senha e/ou dados do perfil (ex.: { data: { username } }) do usuário logado.
    async updateUser({ password, data }: any) {
      const cur = currentUser(); if (!cur) return { data: null, error: { message: "Não autenticado" } };
      const all = users(); const rec = all[cur.email]; if (!rec) return { data: null, error: { message: "Conta não encontrada." } };
      if (typeof password === "string") { if (password.length < 8) return { data: null, error: { message: "A senha precisa ter ao menos 8 caracteres." } }; rec.password = password; }
      if (data) rec.user = { ...rec.user, user_metadata: { ...(rec.user.user_metadata ?? {}), ...data } };
      all[cur.email] = rec; localStorage.setItem(USERS, JSON.stringify(all)); localStorage.setItem(SESSION, JSON.stringify(rec.user)); emit("USER_UPDATED");
      return { data: { user: rec.user }, error: null };
    },
  },
  // Só existe a função de excluir a própria conta (mesmo nome usado no Supabase real).
  async rpc(name: string) {
    const cur = currentUser(); if (!cur) return { data: null, error: { message: "Não autenticado" } };
    if (name !== "delete_my_account") return { data: null, error: { message: "Função desconhecida." } };
    const db = load(); for (const t of Object.keys(db)) db[t] = (db[t] ?? []).filter((r) => r.user_id !== cur.id); save(db);
    const all = users(); delete all[cur.email]; localStorage.setItem(USERS, JSON.stringify(all));
    return { data: null, error: null };
  },
};
