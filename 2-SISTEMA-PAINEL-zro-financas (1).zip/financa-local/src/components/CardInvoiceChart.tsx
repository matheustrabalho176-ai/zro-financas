import { useState } from "react";
import { CartesianGrid, Line, LineChart, ReferenceDot, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { fmt } from "@/lib/finance";

export type HistoryPoint = { key: string; y: number; mo: number; i: number; short: string; full: string; total: number };

const tooltipStyle = { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12, color: "var(--foreground)" };
const compact = (v: number) => (v >= 1000 ? `${(v / 1000).toFixed(v >= 10000 ? 0 : 1).replace(".", ",")}k` : String(v));

/** Linha dos últimos 12 meses. Eixos e rótulos se adaptam à largura disponível (sem rolagem lateral). */
export default function CardInvoiceChart({ data, onPick }: { data: HistoryPoint[]; onPick: (y: number, mo: number) => void }) {
  const [w, setW] = useState(480);
  const narrow = w < 420;
  const tiny = w < 330;
  const last = data[data.length - 1];
  const fs = narrow ? 9 : 12;

  return (
    <ResponsiveContainer width="100%" height="100%" onResize={(width) => setW(width)}>
      <LineChart
        data={data}
        margin={{ top: 10, right: narrow ? 10 : 18, left: 0, bottom: 0 }}
        onClick={(e) => {
          const d = e?.activePayload?.[0]?.payload as HistoryPoint | undefined;
          if (d) onPick(d.y, d.mo);
        }}
      >
        <CartesianGrid stroke="var(--border)" vertical={false} />
        <XAxis
          dataKey="short"
          interval={tiny ? 1 : 0}
          height={narrow ? 38 : 42}
          tickLine={false}
          axisLine={false}
          tick={({ x, y, payload, index }: { x: number; y: number; payload: { value: string }; index: number }) => {
            const h = data[index];
            const isLast = index === data.length - 1;
            return (
              <g transform={`translate(${x},${y})`}>
                <text dy={14} textAnchor="middle" fontSize={fs} fontWeight={isLast ? 700 : 400} fill={isLast ? "var(--primary)" : "var(--muted-foreground)"}>{payload.value}</text>
                {h && (index === 0 || h.mo === 0) && <text dy={27} textAnchor="middle" fontSize={narrow ? 8 : 10} fill="var(--muted-foreground)" opacity={0.7}>{h.y}</text>}
              </g>
            );
          }}
        />
        <YAxis width={narrow ? 36 : 54} stroke="var(--muted-foreground)" fontSize={narrow ? 10 : 12} tickLine={false} axisLine={false} tickFormatter={compact} />
        <Tooltip
          contentStyle={tooltipStyle}
          cursor={{ stroke: "var(--border)" }}
          labelFormatter={(_, p) => (p?.[0]?.payload as HistoryPoint | undefined)?.full ?? ""}
          formatter={(v: number) => [fmt(v), "Fatura"]}
        />
        <Line type="monotone" dataKey="total" name="Fatura" stroke="var(--chart-1)" strokeWidth={2.5}
          dot={{ r: narrow ? 2.5 : 3.5, fill: "var(--chart-1)", strokeWidth: 0 }} activeDot={{ r: 6 }}
          isAnimationActive animationDuration={700} animationEasing="ease-out" />
        {last && <ReferenceDot x={last.short} y={last.total} r={6} fill="var(--chart-1)" stroke="var(--background)" strokeWidth={2} ifOverflow="extendDomain" />}
      </LineChart>
    </ResponsiveContainer>
  );
}
