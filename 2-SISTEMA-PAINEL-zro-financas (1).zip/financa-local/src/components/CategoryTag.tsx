import {
  Car, Clapperboard, GraduationCap, HeartPulse, House, Package, PawPrint, Plane, Receipt, Repeat,
  ShoppingBag, ShoppingCart, Utensils, type LucideIcon,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  Moradia: House, Alimentação: Utensils, Mercado: ShoppingCart, Transporte: Car, Saúde: HeartPulse,
  Educação: GraduationCap, Lazer: Clapperboard, Assinaturas: Repeat, Compras: ShoppingBag,
  Contas: Receipt, Pets: PawPrint, Viagem: Plane, Outros: Package,
};

export function CategoryIcon({ category, className = "size-4" }: { category: string; className?: string }) {
  const Icon = ICONS[category] ?? Package;
  return <Icon className={className} aria-hidden />;
}

/** Tag dourada discreta com ícone + nome da categoria. */
export function CategoryTag({ category }: { category: string }) {
  return (
    <span className="inline-flex max-w-full items-center gap-1.5 rounded-full border border-primary/20 bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
      <CategoryIcon category={category} className="size-3.5 shrink-0" />
      <span className="truncate">{category}</span>
    </span>
  );
}
