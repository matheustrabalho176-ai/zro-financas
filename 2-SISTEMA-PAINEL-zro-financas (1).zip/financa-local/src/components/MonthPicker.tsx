import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MONTHS } from "@/lib/finance";

export function MonthPicker({ year, month, onChange }: { year: number; month: number; onChange: (y: number, m: number) => void }) {
  const step = (d: number) => {
    const dt = new Date(year, month + d, 1);
    onChange(dt.getFullYear(), dt.getMonth());
  };
  return (
    <div className="glass flex w-full items-center justify-between gap-1 rounded-xl p-1 sm:w-auto">
      <Button variant="ghost" size="icon" onClick={() => step(-1)} aria-label="Mês anterior"><ChevronLeft /></Button>
      <span className="min-w-0 flex-1 text-center text-sm font-semibold sm:min-w-32 sm:flex-none">{MONTHS[month]} {year}</span>
      <Button variant="ghost" size="icon" onClick={() => step(1)} aria-label="Próximo mês"><ChevronRight /></Button>
    </div>
  );
}

export function useNow() {
  const d = new Date();
  return { year: d.getFullYear(), month: d.getMonth() };
}
