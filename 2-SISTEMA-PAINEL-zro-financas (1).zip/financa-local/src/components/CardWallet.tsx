import { useRef, useState, type KeyboardEvent, type PointerEvent } from "react";
import { Wifi } from "lucide-react";
import { fmt } from "@/lib/finance";

export type WalletCard = {
  id: string;
  name: string;
  closing_day: number;
  due_day: number;
  invoice: number;
};

/**
 * Ordem do "baralho": o último item é o cartão da frente.
 * Cartões novos entram na frente; os que saíram são removidos.
 */
export function useCardDeck(ids: string[]) {
  const [saved, setSaved] = useState<string[]>([]);
  const present = saved.filter((id) => ids.includes(id));
  const added = ids.filter((id) => !saved.includes(id));
  const order = saved.length === 0 ? [...ids].reverse() : [...present, ...added];
  const n = order.length;
  const activeId = order[n - 1];

  const select = (id: string) => { if (id !== activeId) setSaved([...order.filter((x) => x !== id), id]); };
  /** Manda o cartão da frente para o fundo e traz o próximo. */
  const next = () => { if (n > 1) setSaved([order[n - 1]!, ...order.slice(0, -1)]); };
  /** Traz o cartão do fundo para a frente. */
  const prev = () => { if (n > 1) setSaved([...order.slice(1), order[0]!]); };
  return { order, activeId, select, next, prev };
}

const SKINS = ["wallet-skin-gold", "wallet-skin-black", "wallet-skin-champagne"] as const;

type Props = {
  cards: WalletCard[];
  order: string[];
  monthLabel: string;
  onSelect: (id: string) => void;
  onNext: () => void;
  onPrev: () => void;
};

export function CardWallet({ cards, order, monthLabel, onSelect, onNext, onPrev }: Props) {
  const n = order.length;
  const [dx, setDx] = useState(0);
  const [dragging, setDragging] = useState(false);
  const start = useRef<{ x: number; y: number; id: number } | null>(null);
  const lock = useRef(false);
  const swiped = useRef(false); // evita que o "clique" que o navegador dispara ao soltar o dedo reselecione o cartão
  const dxRef = useRef(0); // valor sempre atual (o estado pode estar defasado quando o dedo solta)
  const move = (v: number) => { dxRef.current = v; setDx(v); };

  const onDown = (e: PointerEvent<HTMLDivElement>) => {
    if (n < 2) return;
    start.current = { x: e.clientX, y: e.clientY, id: e.pointerId };
    lock.current = false;
  };
  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    const s = start.current;
    if (!s) return;
    const mx = e.clientX - s.x;
    const my = e.clientY - s.y;
    if (!lock.current) {
      if (Math.abs(mx) > 10 && Math.abs(mx) > Math.abs(my)) {
        lock.current = true;
        setDragging(true);
        e.currentTarget.setPointerCapture(s.id);
      } else if (Math.abs(my) > 10) {
        start.current = null; // rolagem vertical da página
        return;
      }
    }
    if (lock.current) move(mx);
  };
  const end = () => {
    const moved = dxRef.current;
    start.current = null;
    lock.current = false;
    setDragging(false);
    move(0);
    if (Math.abs(moved) >= 56) {
      swiped.current = true;
      window.setTimeout(() => { swiped.current = false; }, 400);
      if (moved < 0) onNext(); else onPrev();
    }
  };
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "ArrowLeft") { e.preventDefault(); onPrev(); }
    if (e.key === "ArrowRight") { e.preventDefault(); onNext(); }
  };

  const byId = new Map(cards.map((c, i) => [c.id, { card: c, skin: SKINS[i % SKINS.length]! }]));

  return (
    <div className="wallet-wrap mx-auto w-full max-w-md xl:max-w-none" style={{ ["--n" as string]: n }}>
      <div className="wallet" role="group" aria-label="Carteira de cartões" onKeyDown={onKey}>
        {order.map((id, i) => {
          const entry = byId.get(id);
          if (!entry) return null;
          const { card, skin } = entry;
          const depth = n - 1 - i; // 0 = frente
          const active = depth === 0;
          const style = {
            ["--i" as string]: i,
            ["--depth" as string]: depth,
            zIndex: i + 1,
            ...(active && dx !== 0 ? { transform: `translateY(calc(var(--i) * var(--peek))) translateX(${dx}px) rotate(${dx / 24}deg)` } : null),
          };
          return (
            <div
              key={id}
              className={`wallet-card ${skin} ${active ? "is-active" : ""} ${active && dragging ? "is-dragging" : ""}`}
              style={style}
              role={active ? "group" : "button"}
              tabIndex={active ? 0 : 0}
              aria-label={active ? `Cartão ${card.name} selecionado` : `Selecionar cartão ${card.name}`}
              aria-current={active ? "true" : undefined}
              onClick={active ? undefined : () => { if (!swiped.current) onSelect(id); }}
              onKeyDown={active ? undefined : (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onSelect(id); } }}
              onPointerDown={active ? onDown : undefined}
              onPointerMove={active ? onMove : undefined}
              onPointerUp={active ? end : undefined}
              onPointerCancel={active ? end : undefined}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="truncate font-sans text-base font-bold sm:text-lg">{card.name}</span>
                {active ? <Wifi className="size-5 shrink-0 rotate-90" aria-hidden /> : <span className="shrink-0 text-xs font-semibold tabular opacity-90">{fmt(card.invoice)}</span>}
              </div>
              <div className="wallet-card-body">
                <p className="text-xs opacity-80">Fatura de {monthLabel}</p>
                <p className="font-sans text-2xl font-bold tabular sm:text-3xl">{fmt(card.invoice)}</p>
                <p className="mt-1 text-[11px] opacity-80 sm:text-xs">Fecha dia {card.closing_day} • vence {card.due_day}</p>
              </div>
            </div>
          );
        })}
      </div>
      {n > 1 && <p className="mt-3 text-center text-xs text-muted-foreground">Toque na aba de um cartão ou deslize para trocar</p>}
    </div>
  );
}
