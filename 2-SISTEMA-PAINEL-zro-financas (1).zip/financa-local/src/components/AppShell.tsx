import { Link, Outlet, useLocation, useNavigate, useRouteContext } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { LayoutDashboard, ArrowLeftRight, CreditCard, Target, PieChart, FileText, LogOut, ChevronRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Brand } from "@/components/Brand";
import { displayName, initials } from "@/lib/backup";
import { useTilt } from "@/lib/tilt";
import { useIdleLogout } from "@/hooks/use-idle-logout";
import { clearActivity } from "@/lib/session";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/transacoes", label: "Lançamentos", icon: ArrowLeftRight },
  { to: "/cartoes", label: "Cartões", icon: CreditCard },
  { to: "/metas", label: "Metas", icon: Target },
  { to: "/orcamentos", label: "Orçamentos", icon: PieChart },
  { to: "/relatorios", label: "Relatórios", icon: FileText },
] as const;

export function Avatar({ name, className = "size-10 text-sm" }: { name: string; className?: string }) {
  return (
    <span aria-hidden="true" className={`grid shrink-0 place-items-center rounded-full bg-gradient-primary font-bold text-primary-foreground ${className}`}>
      {initials(name)}
    </span>
  );
}

export function AppShell() {
  const { user } = useRouteContext({ from: "/_authenticated" });
  const qc = useQueryClient();
  const navigate = useNavigate();
  const name = displayName(user);
  const { pathname } = useLocation();
  useTilt();
  useIdleLogout();

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    clearActivity();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar/80 p-5 backdrop-blur md:flex">
        <Link to="/dashboard" className="mb-9 flex items-center gap-2 px-1" aria-label="ZRO Finanças — Dashboard">
          <Brand compact />
        </Link>
        <nav className="flex flex-1 flex-col gap-1" aria-label="Menu">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="nav-link flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-sidebar-foreground/70 transition hover:bg-sidebar-accent hover:text-sidebar-foreground"
              activeProps={{ className: "!bg-sidebar-accent !text-primary font-semibold" }}
            >
              <n.icon className="size-4" />
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="rounded-2xl border border-sidebar-border bg-white/[0.02] p-2">
          <Link
            to="/perfil"
            className="nav-link flex items-center gap-3 rounded-xl p-2 transition hover:bg-sidebar-accent"
            activeProps={{ className: "!bg-sidebar-accent" }}
            aria-label="Abrir meu perfil"
          >
            <Avatar name={name} />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-semibold">{name}</span>
              <span className="block truncate text-xs text-muted-foreground">{user.email}</span>
            </span>
            <ChevronRight className="size-4 shrink-0 text-muted-foreground" />
          </Link>
          <Button variant="ghost" size="sm" className="mt-1 w-full justify-start text-muted-foreground" onClick={signOut}>
            <LogOut /> Sair
          </Button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col pb-20 md:pb-0">
        <header className="flex items-center justify-between border-b border-border px-4 py-3 md:hidden">
          <Link to="/dashboard" aria-label="ZRO Finanças — Dashboard"><Brand compact /></Link>
          <div className="flex shrink-0 items-center gap-1">
            <Button variant="ghost" size="icon" onClick={signOut} aria-label="Sair" title="Sair"><LogOut className="size-4" /></Button>
            <Link to="/perfil" aria-label="Abrir meu perfil" title="Meu perfil"><Avatar name={name} className="size-9 text-xs" /></Link>
          </div>
        </header>
        <main className="mx-auto w-full max-w-7xl min-w-0 flex-1 px-3 py-4 sm:p-4 md:p-8">
          <div key={pathname} className="page-enter">
            <Outlet />
          </div>
        </main>
      </div>

      <nav aria-label="Navegação principal" className="mobile-bottom-nav fixed inset-x-0 bottom-0 z-40 flex items-stretch overflow-x-auto border-t border-border bg-sidebar/95 px-1 pt-2 backdrop-blur md:hidden">
        {NAV.map((n) => (
          <Link
            key={n.to}
            to={n.to}
            className="flex min-w-[62px] flex-1 flex-col items-center justify-center gap-1 px-1 pb-1 text-center text-[10px] leading-tight text-muted-foreground"
            activeProps={{ className: "!text-primary font-semibold" }}
          >
            <n.icon className="size-5 shrink-0" />
            <span>{n.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function PageHeader({ title, subtitle, children }: { title: string; subtitle?: string; children?: React.ReactNode }) {
  return (
    <div className="page-header mb-6 flex min-w-0 flex-col items-stretch gap-3 sm:mb-8 sm:flex-row sm:flex-wrap sm:items-end sm:justify-between sm:gap-4">
      <div className="min-w-0">
        <h1 className="text-3xl md:text-4xl">{title}</h1>
        {subtitle && <p className="mt-1.5 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      <div className="page-header-actions flex min-w-0 flex-wrap items-center gap-2">{children}</div>
    </div>
  );
}
