import { useId, type SVGProps } from "react";

/** Marca ZRO em dourado (mesma da página principal). */
export function ZroMark({ className = "", ...props }: SVGProps<SVGSVGElement>) {
  const id = useId().replace(/:/g, "");
  return (
    <svg viewBox="0 0 100 100" aria-hidden="true" className={className} fill="none" {...props}>
      <defs>
        <linearGradient id={`${id}a`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#f7e2a0" /><stop offset=".55" stopColor="#d4a94c" /><stop offset="1" stopColor="#8f6a22" /></linearGradient>
        <linearGradient id={`${id}b`} x1="1" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#b98a31" /><stop offset="1" stopColor="#f0d27c" /></linearGradient>
      </defs>
      <polygon points="50,6 94,92 73,92 50,46 27,92 6,92" fill={`url(#${id}a)`} />
      <polygon points="38,92 50,68 62,92" fill={`url(#${id}b)`} />
    </svg>
  );
}

/** Logotipo: ZRO espaçado + "FINANÇAS" pequeno, como na página principal. */
export function Brand({ compact = false, className = "" }: { compact?: boolean; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <ZroMark className={compact ? "size-9" : "size-11"} />
      <span className="flex flex-col leading-none">
        <span className={`zro-word ${compact ? "text-2xl" : "text-[1.75rem]"}`}>ZRO</span>
        <span className="mt-1.5 text-[9px] font-semibold uppercase tracking-[0.42em] text-primary">Finanças</span>
      </span>
    </span>
  );
}
