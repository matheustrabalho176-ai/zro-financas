import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  cardsQuery, goalsQuery, EXPENSE_CATEGORIES, INCOME_CATEGORIES, type Tx, monthlyDates,
  installmentPlan, withInstallment, MAX_INSTALLMENTS,
} from "@/lib/finance";

type Mode = "income" | "expense";

export function TransactionDialog({
  open, onOpenChange, mode, editing,
}: { open: boolean; onOpenChange: (o: boolean) => void; mode: Mode; editing?: Tx | null }) {
  const qc = useQueryClient();
  const { data: cards = [] } = useQuery(cardsQuery);
  const { data: goals = [] } = useQuery(goalsQuery);
  const today = new Date().toISOString().slice(0, 10);
  const [f, setF] = useState({
    description: "", amount: "", date: today, category: "Outros",
    kind: mode === "income" ? "income" : "variable", paid: true, card_id: "", goal_id: "",
  });

  useEffect(() => {
    if (!open) return;
    if (editing) {
      setF({
        description: editing.description, amount: String(editing.amount), date: editing.date,
        category: editing.category, kind: editing.kind, paid: editing.paid, card_id: editing.card_id ?? "", goal_id: "",
      });
    } else {
      setF({ description: "", amount: "", date: today, category: "Outros",
        kind: mode === "income" ? "income" : "variable", paid: true, card_id: "", goal_id: "" });
    }
  }, [open, editing, mode, today]);

  const [repeat, setRepeat] = useState("1");
  const [totalInst, setTotalInst] = useState("1");
  const [currentInst, setCurrentInst] = useState("1");
  useEffect(() => { if (open) { setRepeat("1"); setTotalInst("1"); setCurrentInst("1"); } }, [open]);
  const isIncome = f.kind === "income";
  const cats = isIncome ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const save = useMutation({
    mutationFn: async () => {
      const amount = Number(f.amount.replace(",", "."));
      if (!f.description.trim() || !(amount > 0)) throw new Error("Preencha descrição e valor");
      if (f.kind === "saving" && !f.goal_id) throw new Error("Selecione a meta que deseja atualizar");
      const row = {
        description: f.description.trim(), amount, date: f.date, category: f.category,
        kind: f.kind, type: isIncome ? "income" : "expense", paid: f.paid,
        card_id: f.kind === "card" && f.card_id ? f.card_id : null,
      };
      let error: { message: string } | null = null;
      if (editing) {
        ({ error } = await supabase.from("transactions").update(row).eq("id", editing.id));
      } else if (f.kind === "card") {
        // Parcelamento: registra a parcela atual neste mês e projeta as restantes.
        const total = Math.floor(Number(totalInst)) || 1;
        const current = Math.floor(Number(currentInst)) || 1;
        if (total < 1 || total > MAX_INSTALLMENTS) throw new Error(`O total de parcelas deve ser entre 1 e ${MAX_INSTALLMENTS}`);
        if (current < 1 || current > total) throw new Error("A parcela inicial deve estar entre 1 e o total de parcelas");
        const plan = installmentPlan(f.date, total, current);
        error = (await supabase.from("transactions").insert(
          plan.map((p, i) => ({
            ...row,
            description: withInstallment(row.description, p.number, p.total).slice(0, 200),
            date: p.date,
            paid: i === 0 ? row.paid : false,
          })),
        )).error;
      } else {
        const n = f.kind === "saving" ? 1 : Math.min(Math.max(Math.floor(Number(repeat)) || 1, 1), 60);
        error = (await supabase.from("transactions").insert(
          monthlyDates(f.date, n).map((date, i) => ({ ...row, date, paid: i === 0 ? row.paid : row.kind === "fixed" ? false : row.paid })),
        )).error;
      }
      if (error) throw error;
      if (f.kind === "saving" && !editing) {
        const goal = goals.find((g) => g.id === f.goal_id);
        if (!goal) throw new Error("A meta selecionada não foi encontrada");
        const { error: goalError } = await supabase.from("goals")
          .update({ current: Number(goal.current) + amount })
          .eq("id", goal.id);
        if (goalError) throw goalError;
      }
    },
    onSuccess: () => {
      toast.success(f.kind === "saving" ? "Valor guardado e meta atualizada" : editing ? "Lançamento atualizado" : "Lançamento salvo");
      qc.invalidateQueries({ queryKey: ["transactions"] });
      qc.invalidateQueries({ queryKey: ["goals"] });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[calc(100%-1rem)] max-h-[90dvh] overflow-y-auto rounded-2xl p-4 sm:w-full sm:max-w-md sm:p-6">
        <DialogHeader>
          <DialogTitle>{editing ? "Editar lançamento" : isIncome ? "Nova receita" : f.kind === "saving" ? "Guardar dinheiro" : "Nova despesa"}</DialogTitle>
        </DialogHeader>
        <form className="min-w-0 space-y-4" onSubmit={(e) => { e.preventDefault(); save.mutate(); }}>
          {!isIncome && (
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {([["fixed", "Fixo"], ["variable", "Variável"], ["card", "Cartão"], ["saving", "Guardar"]] as const).map(([k, l]) => (
                <button type="button" key={k} onClick={() => setF({ ...f, kind: k, paid: k === "card" ? false : k === "fixed" ? f.paid : true })}
                  className={`rounded-xl border px-2 py-2 text-xs font-medium transition ${f.kind === k ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground hover:bg-muted"}`}>
                  {l}
                </button>
              ))}
            </div>
          )}
          <div className="space-y-1.5">
            <Label>Descrição</Label>
            <Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} placeholder={isIncome ? "Ex.: Salário" : "Ex.: Mercado"} />
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>{f.kind === "card" && !editing ? "Valor da parcela (R$)" : "Valor (R$)"}</Label>
              <Input inputMode="decimal" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} placeholder="0,00" />
            </div>
            <div className="space-y-1.5">
              <Label>Data</Label>
              <Input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
            </div>
          </div>
          {f.kind === "saving" && (
            <div className="space-y-1.5">
              <Label>Meta que deseja guardar</Label>
              <Select value={f.goal_id} onValueChange={(v) => setF({ ...f, goal_id: v })}>
                <SelectTrigger className="w-full min-w-0"><SelectValue placeholder={goals.length ? "Selecione uma meta" : "Cadastre uma meta primeiro"} /></SelectTrigger>
                <SelectContent>
                  {goals.map((g) => <SelectItem key={g.id} value={g.id}>{g.name} — {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(g.current))} de {new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(g.target))}</SelectItem>)}
                </SelectContent>
              </Select>
              {goals.length === 0 && <p className="text-xs text-muted-foreground">Crie uma meta na página Metas antes de registrar um valor guardado.</p>}
            </div>
          )}
          {f.kind !== "saving" && (
            <div className="space-y-1.5">
              <Label>Categoria</Label>
              <Select value={f.category} onValueChange={(v) => setF({ ...f, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{cats.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          )}
          {f.kind === "card" && (
            <div className="space-y-1.5">
              <Label>Cartão</Label>
              <Select value={f.card_id} onValueChange={(v) => setF({ ...f, card_id: v })}>
                <SelectTrigger><SelectValue placeholder={cards.length ? "Escolha o cartão" : "Cadastre um cartão primeiro"} /></SelectTrigger>
                <SelectContent>{cards.map((c: { id: string; name: string }) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          )}
          {(f.kind === "fixed" || f.kind === "card") && (
            <div className="flex items-center justify-between rounded-xl border border-border p-3">
              <Label>{f.kind === "card" ? "Compra da fatura já paga" : "Conta paga"}</Label>
              <Switch checked={f.paid} onCheckedChange={(v) => setF({ ...f, paid: v })} />
            </div>
          )}
          {!editing && f.kind === "card" && (
            <div className="space-y-2 rounded-xl border border-border p-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="min-w-0 space-y-1.5">
                  <Label htmlFor="total-inst">Total de parcelas</Label>
                  <Input id="total-inst" type="number" inputMode="numeric" min={1} max={MAX_INSTALLMENTS} value={totalInst}
                    onChange={(e) => setTotalInst(e.target.value)} placeholder="Ex.: 10" />
                </div>
                <div className="min-w-0 space-y-1.5">
                  <Label htmlFor="current-inst">Parcela atual</Label>
                  <Input id="current-inst" type="number" inputMode="numeric" min={1} max={Math.max(Number(totalInst) || 1, 1)} value={currentInst}
                    onChange={(e) => setCurrentInst(e.target.value)} placeholder="1" />
                </div>
              </div>
              {(() => {
                const t = Math.floor(Number(totalInst)) || 1;
                const c = Math.floor(Number(currentInst)) || 1;
                if (t > MAX_INSTALLMENTS || c < 1 || c > t) return <p className="text-xs text-destructive">Confira os números: a parcela atual não pode passar do total (máx. {MAX_INSTALLMENTS}).</p>;
                if (t === 1) return <p className="text-xs text-muted-foreground">Compra à vista. Para parcelar, informe o total de parcelas (ex.: 10).</p>;
                const left = t - c;
                return (
                  <p className="text-xs text-muted-foreground">
                    Será lançada a parcela <span className="font-semibold text-primary">{c}/{t}</span> neste mês
                    {left > 0 ? <> e as {left === 1 ? "parcela" : "parcelas"} <span className="font-semibold text-primary">{c + 1}/{t}{left > 1 ? ` … ${t}/${t}` : ""}</span> nos meses seguintes.</> : "."}
                    {c > 1 && " As parcelas anteriores não são geradas."}
                  </p>
                );
              })()}
            </div>
          )}
          {!editing && f.kind !== "saving" && f.kind !== "card" && (
            <div className="space-y-1.5">
              <Label>Repetir por quantos meses?</Label>
              <Input type="number" min={1} max={60} value={repeat} onChange={(e) => setRepeat(e.target.value)} />
              <p className="text-xs text-muted-foreground">Use 1 para lançar só neste mês. Ex.: 12 para o aluguel do ano todo.</p>
            </div>
          )}
          <Button variant="hero" type="submit" className="h-11 w-full" disabled={save.isPending || (f.kind === "saving" && goals.length === 0)}>{f.kind === "saving" ? "Guardar e atualizar meta" : "Salvar"}</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
