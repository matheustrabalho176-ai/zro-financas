import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { FileUp, LoaderCircle, Trash2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { txYearQuery, EXPENSE_CATEGORIES, INCOME_CATEGORIES, fmt } from '@/lib/finance';
import { parseStatementText, type ImportedStatementRow } from '@/lib/statement-import';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function StatementImportDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [rows, setRows] = useState<ImportedStatementRow[]>([]);
  const [fileName, setFileName] = useState('');
  const [reading, setReading] = useState(false);
  const qc = useQueryClient();
  const { data: existing = [] } = useQuery(txYearQuery(new Date().getFullYear()));
  const selectedRows = rows.filter(r => r.selected && !r.duplicate);
  const total = selectedRows.reduce((sum, r) => sum + (r.type === 'income' ? r.amount : -r.amount), 0);
  const mutation = useMutation({
    mutationFn: async () => {
      if (!selectedRows.length) throw new Error('Selecione pelo menos um lançamento sem duplicidade.');
      const payload = selectedRows.map(({ date, description, amount, type, category }) => ({
        date, description, amount, type, category,
        kind: type === 'income' ? 'income' : 'variable', paid: true, card_id: null,
      }));
      const { error } = await supabase.from('transactions').insert(payload);
      if (error) throw error;
      return payload.length;
    },
    onSuccess: count => {
      toast.success(`${count} lançamento(s) importado(s).`);
      qc.invalidateQueries({ queryKey: ['transactions'] });
      setRows([]); setFileName(''); onOpenChange(false);
    },
    onError: (error: Error) => toast.error(error.message || 'Não foi possível importar os lançamentos.'),
  });

  const duplicateKeys = useMemo(() => new Set(existing.map(t => `${t.date}|${t.description.trim().toLowerCase()}|${Number(t.amount).toFixed(2)}|${t.type}`)), [existing]);

  async function readFile(file?: File) {
    if (!file) return;
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      toast.error('Selecione um arquivo PDF.'); return;
    }
    if (file.size > 15 * 1024 * 1024) { toast.error('O PDF deve ter no máximo 15 MB.'); return; }
    setReading(true); setFileName(file.name); setRows([]);
    try {
      const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
      const buffer = await file.arrayBuffer();
      const pdf = await pdfjs.getDocument({ data: new Uint8Array(buffer), useWorkerFetch: false, isEvalSupported: false, useSystemFonts: true }).promise;
      let text = '';
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        text += '\n' + content.items.map((item: unknown) => typeof item === 'object' && item !== null && 'str' in item ? String((item as { str: string }).str) : '').join(' ');
      }
      const parsed = parseStatementText(text);
      if (!parsed.length) throw new Error('Não encontrei lançamentos legíveis. Se o PDF for digitalizado como imagem, será necessário OCR; tente baixar o extrato em PDF pesquisável.');
      setRows(parsed.map((r, i) => {
        const key = `${r.date}|${r.description.trim().toLowerCase()}|${r.amount.toFixed(2)}|${r.type}`;
        const duplicate = duplicateKeys.has(key);
        return { ...r, id: `${i}-${key}`, duplicate, selected: !duplicate };
      }));
      toast.success(`${parsed.length} lançamento(s) identificado(s). Confira antes de importar.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Não foi possível ler este PDF.');
    } finally { setReading(false); }
  }

  function updateRow(id: string, patch: Partial<ImportedStatementRow>) {
    setRows(current => current.map(r => r.id === id ? { ...r, ...patch } : r));
  }
  const close = (value: boolean) => { if (!value && mutation.isPending) return; onOpenChange(value); if (!value) { setRows([]); setFileName(''); } };

  return <Dialog open={open} onOpenChange={close}>
    <DialogContent className="max-h-[90dvh] max-w-4xl overflow-y-auto rounded-2xl">
      <DialogHeader><DialogTitle>Importar extrato bancário (PDF)</DialogTitle><DialogDescription>O arquivo é processado no navegador. Revise os dados e confirme antes de gravar no sistema.</DialogDescription></DialogHeader>
      <div className="space-y-4">
        <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-border p-6 text-center hover:bg-muted/40">
          {reading ? <LoaderCircle className="size-7 animate-spin" /> : <FileUp className="size-7 text-primary" />}
          <span className="font-medium">{reading ? 'Lendo o extrato…' : fileName || 'Escolher arquivo PDF'}</span>
          <span className="text-xs text-muted-foreground">Vários bancos • PDF pesquisável • até 15 MB</span>
          <Input type="file" accept="application/pdf,.pdf" className="hidden" disabled={reading || mutation.isPending} onChange={e => { void readFile(e.target.files?.[0]); e.currentTarget.value = ''; }} />
        </label>
        {rows.length > 0 && <>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <div className="rounded-xl bg-muted/50 p-3"><p className="text-xs text-muted-foreground">Identificados</p><p className="text-lg font-semibold">{rows.length}</p></div>
            <div className="rounded-xl bg-muted/50 p-3"><p className="text-xs text-muted-foreground">Selecionados</p><p className="text-lg font-semibold">{selectedRows.length}</p></div>
            <div className="rounded-xl bg-muted/50 p-3"><p className="text-xs text-muted-foreground">Possíveis duplicados</p><p className="text-lg font-semibold">{rows.filter(r => r.duplicate).length}</p></div>
            <div className="rounded-xl bg-muted/50 p-3"><p className="text-xs text-muted-foreground">Saldo selecionado</p><p className="text-lg font-semibold">{fmt(total)}</p></div>
          </div>
          <div className="space-y-3">
            {rows.map((r) => <div key={r.id} className={`space-y-2 rounded-xl border p-3 ${r.duplicate ? 'border-amber-500/50 bg-amber-500/5' : 'border-border'}`}>
              <div className="flex items-start gap-2">
                <input aria-label="Selecionar lançamento" type="checkbox" className="mt-2 size-4 accent-primary" checked={r.selected} disabled={r.duplicate} onChange={e => updateRow(r.id, { selected: e.target.checked })} />
                <div className="grid min-w-0 flex-1 grid-cols-1 gap-2 sm:grid-cols-12">
                  <Input type="date" className="sm:col-span-3" value={r.date} onChange={e => updateRow(r.id, { date: e.target.value })} />
                  <Input className="sm:col-span-5" value={r.description} onChange={e => updateRow(r.id, { description: e.target.value })} />
                  <Input className="sm:col-span-2" inputMode="decimal" value={String(r.amount).replace('.', ',')} onChange={e => { const n = Number(e.target.value.replace(/\./g, '').replace(',', '.')); if (Number.isFinite(n)) updateRow(r.id, { amount: n }); }} />
                  <Select value={r.type} onValueChange={v => updateRow(r.id, { type: v as 'income' | 'expense', category: v === 'income' ? 'Outros' : 'Outros' })}><SelectTrigger className="sm:col-span-2"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="income">Receita</SelectItem><SelectItem value="expense">Despesa</SelectItem></SelectContent></Select>
                  <Select value={r.category} onValueChange={v => updateRow(r.id, { category: v })}><SelectTrigger className="sm:col-span-12"><SelectValue /></SelectTrigger><SelectContent>{(r.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES).map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select>
                </div>
                <Button type="button" size="icon" variant="ghost" aria-label="Remover da lista" onClick={() => setRows(current => current.filter(x => x.id !== r.id))}><Trash2 className="size-4" /></Button>
              </div>
              {r.duplicate && <p className="pl-6 text-xs text-amber-700">Possível duplicidade com lançamento já existente; não será importado novamente.</p>}
            </div>)}
          </div>
          <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
            <Button variant="outline" onClick={() => { setRows([]); setFileName(''); }}>Limpar</Button>
            <Button disabled={!selectedRows.length || mutation.isPending} onClick={() => mutation.mutate()}>{mutation.isPending ? 'Importando…' : `Importar ${selectedRows.length} lançamento(s)`}</Button>
          </div>
        </>}
      </div>
    </DialogContent>
  </Dialog>;
}
