import { useEffect } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { clearActivity, flagIdleLogout, IDLE_MS, isExpired, readActivity, touchActivity } from "@/lib/session";

const EVENTS = ["pointerdown", "keydown", "wheel", "touchstart", "scroll", "mousemove"] as const;
const WRITE_EVERY_MS = 10_000;
const CHECK_EVERY_MS = 15_000;

/** Encerra a sessão após 30 min sem uso. Qualquer interação renova o prazo. */
export function useIdleLogout() {
  const navigate = useNavigate();
  const qc = useQueryClient();

  useEffect(() => {
    let done = false;
    let lastWrite = 0;

    const logout = async () => {
      if (done) return;
      done = true;
      flagIdleLogout();
      clearActivity();
      await qc.cancelQueries();
      qc.clear();
      await supabase.auth.signOut({ scope: "local" });
      navigate({ to: "/auth", replace: true });
    };

    const check = () => {
      if (isExpired(readActivity(), Date.now(), IDLE_MS)) void logout();
    };

    const onActivity = () => {
      const now = Date.now();
      if (now - lastWrite < WRITE_EVERY_MS) return;
      // Se o prazo já estourou (ex.: computador suspenso), o toque não "ressuscita" a sessão.
      if (isExpired(readActivity(), now, IDLE_MS)) { void logout(); return; }
      lastWrite = now;
      touchActivity(now);
    };

    const onVisible = () => { if (document.visibilityState === "visible") check(); };

    check();
    EVENTS.forEach((e) => window.addEventListener(e, onActivity, { passive: true, capture: true }));
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", check);
    const id = window.setInterval(check, CHECK_EVERY_MS);
    return () => {
      EVENTS.forEach((e) => window.removeEventListener(e, onActivity, { capture: true }));
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", check);
      window.clearInterval(id);
    };
  }, [navigate, qc]);
}
