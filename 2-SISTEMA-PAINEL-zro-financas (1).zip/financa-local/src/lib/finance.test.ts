import { describe, it, expect } from "vitest";
import { summarize } from "./finance";

describe("summarize", () => {
  it("only counts fixed expenses that are paid", () => {
    const s = summarize([
      { kind: "fixed", amount: 100, paid: true },
      { kind: "fixed", amount: 50, paid: false },
    ]);
    expect(s.fixed).toBe(100);
  });
  it("card expenses only count when paid", () => {
    const s = summarize([
      { kind: "income", amount: 3559.83, paid: true },
      { kind: "fixed", amount: 76.17, paid: true },
      { kind: "variable", amount: 331.77, paid: true },
      { kind: "card", amount: 1080.14, paid: false },
      { kind: "saving", amount: 1000, paid: true },
    ]);
    expect(s.balance).toBeCloseTo(2151.89, 2);
  });
});

import { monthlyDates } from "./finance";
describe("monthlyDates", () => {
  it("repeats monthly and clamps day 31 to month end", () => {
    expect(monthlyDates("2026-01-31", 3)).toEqual(["2026-01-31", "2026-02-28", "2026-03-31"]);
  });
  it("crosses year boundary", () => {
    expect(monthlyDates("2026-12-10", 2)).toEqual(["2026-12-10", "2027-01-10"]);
  });
});

import { installmentPlan, parseInstallment, withInstallment, lastMonths } from "./finance";
describe("parcelamento", () => {
  it("5/10 gera 5/10 … 10/10 sem parcelas retroativas", () => {
    const p = installmentPlan("2026-10-25", 10, 5);
    expect(p).toHaveLength(6);
    expect(p[0]).toEqual({ date: "2026-10-25", number: 5, total: 10 });
    expect(p[5]).toEqual({ date: "2027-03-25", number: 10, total: 10 });
  });
  it("padrão começa em 1/N", () => {
    expect(installmentPlan("2026-01-31", 3).map((x) => x.date)).toEqual(["2026-01-31", "2026-02-28", "2026-03-31"]);
  });
  it("monta e interpreta o texto da parcela", () => {
    expect(withInstallment(" Curso Online ", 5, 10)).toBe("Curso Online (5/10)");
    expect(withInstallment("Mercado", 1, 1)).toBe("Mercado");
    expect(parseInstallment("Curso Online (5/10)")).toEqual({ base: "Curso Online", number: 5, total: 10 });
    expect(parseInstallment("Mercado")).toBeNull();
  });
  it("lastMonths devolve 12 meses terminando no selecionado", () => {
    const l = lastMonths(2026, 1);
    expect(l).toHaveLength(12);
    expect(l[0]).toEqual({ year: 2025, month: 2 });
    expect(l[11]).toEqual({ year: 2026, month: 1 });
  });
});
