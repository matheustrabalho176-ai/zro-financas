/**
 * Sessão com expiração por inatividade.
 * - Enquanto a pessoa usa o sistema (clique, toque, teclado, rolagem) o relógio é renovado.
 * - Após IDLE_MS sem nenhuma interação a sessão é encerrada.
 * O carimbo fica no localStorage para valer entre abas, recargas e suspensão do computador.
 */
export const IDLE_MS = 30 * 60 * 1000;
export const ACTIVITY_KEY = "zro:last-activity";
export const IDLE_FLAG_KEY = "zro:idle-logout";

export const isExpired = (stamp: number | null, now = Date.now(), limit = IDLE_MS) =>
  stamp === null || !Number.isFinite(stamp) || now - stamp >= limit;

export function readActivity(): number | null {
  try {
    const raw = window.localStorage.getItem(ACTIVITY_KEY);
    return raw ? Number(raw) : null;
  } catch {
    return null;
  }
}

export function touchActivity(now = Date.now()) {
  try { window.localStorage.setItem(ACTIVITY_KEY, String(now)); } catch { /* storage bloqueado */ }
}

export function clearActivity() {
  try { window.localStorage.removeItem(ACTIVITY_KEY); } catch { /* noop */ }
}

export const sessionIdleExpired = () => isExpired(readActivity());

export function flagIdleLogout() {
  try { window.sessionStorage.setItem(IDLE_FLAG_KEY, "1"); } catch { /* noop */ }
}

/** Lê e apaga o aviso de "sessão encerrada por inatividade". */
export function consumeIdleFlag(): boolean {
  try {
    const v = window.sessionStorage.getItem(IDLE_FLAG_KEY);
    if (v) window.sessionStorage.removeItem(IDLE_FLAG_KEY);
    return Boolean(v);
  } catch {
    return false;
  }
}
