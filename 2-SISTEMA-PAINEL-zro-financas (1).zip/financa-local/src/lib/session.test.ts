import { describe, expect, it } from "vitest";
import { IDLE_MS, isExpired } from "./session";

describe("expiração por inatividade", () => {
  const now = 1_000_000_000_000;
  it("mantém a sessão enquanto houve uso nos últimos 30 min", () => {
    expect(isExpired(now - 29 * 60_000, now)).toBe(false);
    expect(isExpired(now, now)).toBe(false);
  });
  it("encerra com 30 min ou mais sem uso", () => {
    expect(isExpired(now - IDLE_MS, now)).toBe(true);
    expect(isExpired(now - 3 * 60 * 60_000, now)).toBe(true);
  });
  it("sem registro de uso exige novo login", () => {
    expect(isExpired(null, now)).toBe(true);
    expect(isExpired(Number.NaN, now)).toBe(true);
  });
});
