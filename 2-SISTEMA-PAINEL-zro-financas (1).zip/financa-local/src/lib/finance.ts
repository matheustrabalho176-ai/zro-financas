import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Tx = Tables<"transactions">;
export type Card = Tables<"cards">;
export type Goal = Tables<"goals">;
export type Budget = Tables<"budgets">;

export const MONTHS = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
];

export const INCOME_CATEGORIES = ["Salário", "Freelance", "Investimentos", "Vendas", "Presente", "Outros"];
export const EXPENSE_CATEGORIES = [
  "Moradia", "Alimentação", "Mercado", "Transporte", "Saúde", "Educação",
  "Lazer", "Assinaturas", "Compras", "Contas", "Pets", "Viagem", "Outros",
];

export const KIND_LABEL: Record<string, string> = {
  income: "Entrada",
  fixed: "Gasto fixo",
  variable: "Gasto variável",
  card: "Cartão de crédito",
  saving: "Guardado",
};

const brl = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
export const fmt = (v: number) => brl.format(v || 0);

export function monthRange(year: number, month: number) {
  const start = new Date(year, month, 1);
  const end = new Date(year, month + 1, 0);
  const iso = (d: Date) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return { start: iso(start), end: iso(end) };
}

export type MonthSummary = {
  income: number;
  fixed: number;
  variable: number;
  card: number;
  saving: number;
  expenses: number;
  balance: number;
};

/** Saldo = entradas - (fixos pagos + variáveis + cartões pagos) - guardado */
export function summarize(txs: Pick<Tx, "kind" | "amount" | "paid">[]): MonthSummary {
  const s = { income: 0, fixed: 0, variable: 0, card: 0, saving: 0 };
  for (const t of txs) {
    const v = Number(t.amount);
    if (t.kind === "income") s.income += v;
    else if (t.kind === "fixed") { if (t.paid) s.fixed += v; }
    else if (t.kind === "variable") s.variable += v;
    else if (t.kind === "card") { if (t.paid) s.card += v; }
    else if (t.kind === "saving") s.saving += v;
  }
  const expenses = s.fixed + s.variable + s.card;
  return { ...s, expenses, balance: s.income - expenses - s.saving };
}

export function pctChange(cur: number, prev: number) {
  if (!prev) return null;
  return ((cur - prev) / prev) * 100;
}

export const txYearQuery = (year: number) =>
  queryOptions({
    queryKey: ["transactions", year],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .gte("date", `${year}-01-01`)
        .lte("date", `${year}-12-31`)
        .order("date", { ascending: false })
        .limit(5000);
      if (error) throw error;
      return data;
    },
  });

export const cardsQuery = queryOptions({
  queryKey: ["cards"],
  queryFn: async () => {
    const { data, error } = await supabase.from("cards").select("*").order("created_at");
    if (error) throw error;
    return data;
  },
});
export const goalsQuery = queryOptions({
  queryKey: ["goals"],
  queryFn: async () => {
    const { data, error } = await supabase.from("goals").select("*").order("created_at");
    if (error) throw error;
    return data;
  },
});
export const budgetsQuery = queryOptions({
  queryKey: ["budgets"],
  queryFn: async () => {
    const { data, error } = await supabase.from("budgets").select("*").order("category");
    if (error) throw error;
    return data;
  },
});

export function byMonth(txs: Tx[]) {
  return MONTHS.map((name, m) => {
    const list = txs.filter((t) => Number(t.date.slice(5, 7)) - 1 === m);
    return { name, short: name.slice(0, 3), month: m, ...summarize(list) };
  });
}

/** Returns `count` ISO dates, one per month starting at `start`, clamping to the month's last day. */
export function monthlyDates(start: string, count: number): string[] {
  const [y = 0, m = 1, d = 1] = start.split("-").map(Number);
  const out: string[] = [];
  for (let i = 0; i < count; i++) {
    const total = m - 1 + i;
    const yy = y + Math.floor(total / 12);
    const mm = total % 12;
    const last = new Date(Date.UTC(yy, mm + 1, 0)).getUTCDate();
    out.push(`${yy}-${String(mm + 1).padStart(2, "0")}-${String(Math.min(d, last)).padStart(2, "0")}`);
  }
  return out;
}

/* ───────────── Parcelamento no cartão ───────────── */

export const MAX_INSTALLMENTS = 60;

/** "5/10" */
export const installmentLabel = (number: number, total: number) => `${number}/${total}`;

export type InstallmentPlan = { date: string; number: number; total: number };

/**
 * Projeta as parcelas de `current` até `total`, uma por mês, a partir de `start`.
 * Parcelas anteriores a `current` não são geradas (evita poluir meses passados).
 * Ex.: total 10, current 5 → 5/10 no mês de `start`, 6/10 no mês seguinte ... 10/10.
 */
export function installmentPlan(start: string, total: number, current = 1): InstallmentPlan[] {
  const t = Math.min(Math.max(Math.floor(total) || 1, 1), MAX_INSTALLMENTS);
  const c = Math.min(Math.max(Math.floor(current) || 1, 1), t);
  return monthlyDates(start, t - c + 1).map((date, i) => ({ date, number: c + i, total: t }));
}

/** Acrescenta " (5/10)" à descrição. Compra à vista (total = 1) não recebe sufixo. */
export function withInstallment(description: string, number: number, total: number) {
  return total > 1 ? `${description.trim()} (${installmentLabel(number, total)})` : description.trim();
}

/** Separa "Curso Online (5/10)" em { base: "Curso Online", number: 5, total: 10 }. */
export function parseInstallment(description: string): { base: string; number: number; total: number } | null {
  const m = description.match(/^(.*?)\s*\((\d{1,3})\/(\d{1,3})\)\s*$/);
  if (!m) return null;
  const number = Number(m[2]);
  const total = Number(m[3]);
  if (!m[1] || number < 1 || total < 2 || number > total) return null;
  return { base: m[1], number, total };
}

/** Os `count` meses terminando em (year, month), do mais antigo ao mais recente. */
export function lastMonths(year: number, month: number, count = 12) {
  return Array.from({ length: count }, (_, i) => {
    const d = new Date(year, month - (count - 1 - i), 1);
    return { year: d.getFullYear(), month: d.getMonth() };
  });
}
