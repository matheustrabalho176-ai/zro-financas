import { supabase } from "@/integrations/supabase/client";

/** Exporta todos os dados do usuário logado para um arquivo JSON e dispara o download. */
export async function exportBackup() {
  const allTransactions: unknown[] = [];
  for (let from = 0; ; from += 1000) {
    const page = await supabase.from("transactions").select("*").order("created_at", { ascending: true }).range(from, from + 999);
    if (page.error) throw page.error;
    allTransactions.push(...(page.data ?? []));
    if (!page.data || page.data.length < 1000) break;
  }
  const [cards, goals, budgets] = await Promise.all([
    supabase.from("cards").select("*").order("created_at", { ascending: true }),
    supabase.from("goals").select("*").order("created_at", { ascending: true }),
    supabase.from("budgets").select("*").order("created_at", { ascending: true }),
  ]);
  for (const result of [cards, goals, budgets]) if (result.error) throw result.error;
  const backup = {
    app: "Zro Finanças",
    formatVersion: 1,
    exportedAt: new Date().toISOString(),
    data: { transactions: allTransactions, cards: cards.data ?? [], goals: goals.data ?? [], budgets: budgets.data ?? [] },
  };
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `zro-financas-backup-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export type ImportResult = { transactions: number; cards: number; goals: number; budgets: number };

/** Importa um backup exportado pelo Zro Finanças para a conta logada. */
export async function importBackup(file: File): Promise<ImportResult> {
  const parsed = JSON.parse(await file.text());
  if (
    parsed?.app !== "Zro Finanças" || parsed?.formatVersion !== 1 || !parsed?.data ||
    !Array.isArray(parsed.data.transactions) || !Array.isArray(parsed.data.cards) ||
    !Array.isArray(parsed.data.goals) || !Array.isArray(parsed.data.budgets)
  ) {
    throw new Error("Arquivo inválido. Selecione um backup exportado pelo Zro Finanças.");
  }
  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError || !authData.user) throw new Error("Faça login novamente antes de importar.");
  const userId = authData.user.id;

  const cardIdMap = new Map<string, string>();
  let cardCount = 0;
  for (const card of parsed.data.cards) {
    const { data, error } = await supabase
      .from("cards")
      .insert({ name: card.name, color: card.color, credit_limit: card.credit_limit, closing_day: card.closing_day, due_day: card.due_day, user_id: userId })
      .select("id")
      .single();
    if (error) throw error;
    if (card.id) cardIdMap.set(card.id, data.id);
    cardCount++;
  }
  const goals = parsed.data.goals.map((g: { name: string; target: number; current: number; deadline?: string | null }) => ({
    name: g.name, target: g.target, current: g.current, deadline: g.deadline ?? null, user_id: userId,
  }));
  if (goals.length) { const { error } = await supabase.from("goals").insert(goals); if (error) throw error; }
  const budgets = parsed.data.budgets.map((b: { category: string; amount: number }) => ({ category: b.category, amount: b.amount, user_id: userId }));
  if (budgets.length) { const { error } = await supabase.from("budgets").upsert(budgets, { onConflict: "user_id,category" }); if (error) throw error; }
  const transactions = parsed.data.transactions.map(
    (t: { description: string; amount: number; type: string; kind: string; category: string; date: string; paid: boolean; card_id?: string | null }) => ({
      description: t.description, amount: t.amount, type: t.type, kind: t.kind, category: t.category, date: t.date, paid: t.paid,
      card_id: typeof t.card_id === "string" ? (cardIdMap.get(t.card_id) ?? null) : null, user_id: userId,
    }),
  );
  if (transactions.length) { const { error } = await supabase.from("transactions").insert(transactions); if (error) throw error; }
  return { transactions: transactions.length, cards: cardCount, goals: goals.length, budgets: budgets.length };
}

/** Nome de exibição: usuário escolhido ou, na falta dele, a parte local do e-mail. */
export function displayName(user: { email?: string | null; user_metadata?: Record<string, unknown> | null }) {
  const meta = user.user_metadata?.["username"];
  if (typeof meta === "string" && meta.trim()) return meta.trim();
  const local = (user.email ?? "usuário").split("@")[0]!;
  return local.charAt(0).toUpperCase() + local.slice(1);
}

export function initials(name: string) {
  const parts = name.replace(/[^\p{L}\p{N}\s._-]/gu, "").split(/[\s._-]+/).filter(Boolean);
  return ((parts[0]?.[0] ?? "?") + (parts.length > 1 ? parts[parts.length - 1]![0]! : "")).toUpperCase();
}
