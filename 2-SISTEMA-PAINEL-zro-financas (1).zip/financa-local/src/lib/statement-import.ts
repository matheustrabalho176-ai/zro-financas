import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from './finance';

export type ImportedStatementRow = {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: string;
  selected: boolean;
  duplicate: boolean;
};

function isoDate(raw: string): string | null {
  const s = raw.replace(/\s/g, '');
  let d: number, m: number, y: number;
  let match = s.match(/^(\d{2})[/.\-](\d{2})[/.\-](\d{2,4})$/);
  if (match) {
    d = Number(match[1]); m = Number(match[2]); y = Number(match[3]);
    if (y < 100) y += y < 70 ? 2000 : 1900;
  } else {
    match = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return null;
    y = Number(match[1]); m = Number(match[2]); d = Number(match[3]);
  }
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}

function money(raw: string): number | null {
  let s = raw.replace(/R\$|\s/g, '').replace(/[()]/g, '');
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  const n = Number(s);
  return Number.isFinite(n) && n !== 0 ? Math.abs(n) : null;
}

function classify(description: string, isIncome: boolean) {
  const d = description.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  if (isIncome) {
    if (/salario|folha de pagamento|pagto salario|proventos/.test(d)) return 'Salário';
    if (/pix recebido|ted recebida|deposito|transferencia recebida/.test(d)) return 'Outros';
    if (/rendimento|juros|dividendo/.test(d)) return 'Investimentos';
    return INCOME_CATEGORIES.includes('Outros') ? 'Outros' : INCOME_CATEGORIES[0];
  }
  if (/uber|99app|taxi|onibus|combustivel|posto /.test(d)) return 'Transporte';
  if (/ifood|restaurante|lanchonete|padaria|cafe/.test(d)) return 'Alimentação';
  if (/supermercado|mercado|atacadao|mercantil/.test(d)) return 'Mercado';
  if (/farmacia|hospital|clinica|laboratorio/.test(d)) return 'Saúde';
  if (/netflix|spotify|youtube|prime video|assinatura/.test(d)) return 'Assinaturas';
  if (/energia|equatorial|agua|internet|telefone|aluguel|condominio/.test(d)) return 'Contas';
  return EXPENSE_CATEGORIES.includes('Outros') ? 'Outros' : EXPENSE_CATEGORIES[0];
}

/** Best-effort parser for common text-based Brazilian bank statement PDFs. Always review results before saving. */
export function parseStatementText(text: string): Omit<ImportedStatementRow, 'id' | 'selected' | 'duplicate'>[] {
  const rows: Omit<ImportedStatementRow, 'id' | 'selected' | 'duplicate'>[] = [];
  const lines = text.split(/\r?\n/).map(x => x.replace(/\s+/g, ' ').trim()).filter(Boolean);
  const seen = new Set<string>();
  for (const line of lines) {
    const dateMatch = line.match(/(^|\s)(\d{2}[/.\-]\d{2}[/.\-]\d{2,4}|\d{4}-\d{2}-\d{2})(?=\s|$)/);
    if (!dateMatch) continue;
    const date = isoDate(dateMatch[2]);
    if (!date) continue;
    const rest = line.slice((dateMatch.index ?? 0) + dateMatch[0].length).trim();
    const amounts = [...rest.matchAll(/(?:R\$\s*)?(-?\d{1,3}(?:\.\d{3})*,\d{2}|-?\d+\.\d{2})(\s*[DC])?/gi)];
    if (!amounts.length) continue;
    const last = amounts[amounts.length - 1];
    const amount = money(last[1]);
    if (!amount) continue;
    const description = rest.slice(0, last.index).replace(/[|;\-–]+$/g, '').trim();
    if (!description || /saldo (anterior|do dia|final)|total de lancamentos/i.test(description)) continue;
    const suffix = (last[2] ?? '').trim().toUpperCase();
    const signed = last[1].startsWith('-') || suffix === 'D' || /\bdebito\b|\bcompra\b/i.test(description);
    const type = signed ? 'expense' : 'income';
    const key = `${date}|${description.toLowerCase()}|${amount}|${type}`;
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push({ date, description: description.slice(0, 180), amount, type, category: classify(description, type === 'income') });
  }
  return rows;
}
